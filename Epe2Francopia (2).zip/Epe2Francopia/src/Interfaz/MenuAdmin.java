package Interfaz;

import Conectar.DaoHistorial;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MenuAdmin extends javax.swing.JFrame {

    DaoHistorial hist = new DaoHistorial();
    
    public MenuAdmin() throws ClassNotFoundException {
        initComponents();
        hist.cargarTabla(tablahistorial);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoazuliptitulo = new javax.swing.JPanel();
        titulotienda = new javax.swing.JLabel();
        BG = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablahistorial = new javax.swing.JTable();
        bguser = new javax.swing.JPanel();
        iconoadmin = new javax.swing.JLabel();
        bienvenidatext = new javax.swing.JLabel();
        txtnombreadmin = new javax.swing.JLabel();
        btngestionbodega = new javax.swing.JButton();
        btngestionuser1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        btngestionmarca = new javax.swing.JButton();
        btngestionventa = new javax.swing.JButton();
        fondoazuliptitulo1 = new javax.swing.JPanel();
        titulotienda1 = new javax.swing.JLabel();
        FlechaFondo = new javax.swing.JLabel();
        FlechaFondo1 = new javax.swing.JLabel();

        fondoazuliptitulo.setBackground(new java.awt.Color(51, 102, 255));

        titulotienda.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulotienda.setForeground(new java.awt.Color(255, 255, 255));
        titulotienda.setText("TIENDITA");

        javax.swing.GroupLayout fondoazuliptituloLayout = new javax.swing.GroupLayout(fondoazuliptitulo);
        fondoazuliptitulo.setLayout(fondoazuliptituloLayout);
        fondoazuliptituloLayout.setHorizontalGroup(
            fondoazuliptituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondoazuliptituloLayout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addComponent(titulotienda)
                .addGap(45, 45, 45))
        );
        fondoazuliptituloLayout.setVerticalGroup(
            fondoazuliptituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptituloLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(titulotienda, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BG.setBackground(new java.awt.Color(234, 234, 234));
        BG.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablahistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablahistorial);

        BG.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 500, 370));

        bguser.setBackground(new java.awt.Color(199, 83, 157));
        bguser.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bguser.setForeground(new java.awt.Color(51, 102, 255));

        iconoadmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/usericon32x.png"))); // NOI18N

        bienvenidatext.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        bienvenidatext.setForeground(new java.awt.Color(255, 255, 255));
        bienvenidatext.setText("Bienvenido/a");

        txtnombreadmin.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtnombreadmin.setForeground(new java.awt.Color(255, 255, 255));
        txtnombreadmin.setText("test");

        btngestionbodega.setBackground(new java.awt.Color(51, 102, 255));
        btngestionbodega.setForeground(new java.awt.Color(255, 255, 255));
        btngestionbodega.setText("Gestión De Inventario");
        btngestionbodega.setBorder(null);
        btngestionbodega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngestionbodegaActionPerformed(evt);
            }
        });

        btngestionuser1.setBackground(new java.awt.Color(51, 102, 255));
        btngestionuser1.setForeground(new java.awt.Color(255, 255, 255));
        btngestionuser1.setText("Gestión De Trabadores / Clientes");
        btngestionuser1.setBorder(null);
        btngestionuser1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngestionuser1ActionPerformed(evt);
            }
        });

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));

        btngestionmarca.setBackground(new java.awt.Color(51, 102, 255));
        btngestionmarca.setForeground(new java.awt.Color(255, 255, 255));
        btngestionmarca.setText("Gestión De Marca, Categoria y Bodega");
        btngestionmarca.setBorder(null);
        btngestionmarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngestionmarcaActionPerformed(evt);
            }
        });

        btngestionventa.setBackground(new java.awt.Color(51, 102, 255));
        btngestionventa.setForeground(new java.awt.Color(255, 255, 255));
        btngestionventa.setText("Ventas");
        btngestionventa.setBorder(null);
        btngestionventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngestionventaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bguserLayout = new javax.swing.GroupLayout(bguser);
        bguser.setLayout(bguserLayout);
        bguserLayout.setHorizontalGroup(
            bguserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bguserLayout.createSequentialGroup()
                .addGroup(bguserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bguserLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(iconoadmin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bguserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator1)
                            .addGroup(bguserLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(txtnombreadmin))
                            .addComponent(bienvenidatext, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 14, Short.MAX_VALUE))
                    .addGroup(bguserLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btngestionuser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(bguserLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btngestionmarca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(bguserLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btngestionbodega, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(bguserLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btngestionventa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        bguserLayout.setVerticalGroup(
            bguserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bguserLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(bguserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(iconoadmin)
                    .addGroup(bguserLayout.createSequentialGroup()
                        .addComponent(bienvenidatext, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtnombreadmin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(48, 48, 48)
                .addComponent(btngestionuser1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btngestionmarca, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(btngestionbodega, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btngestionventa, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        BG.add(bguser, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 0, 260, 500));

        fondoazuliptitulo1.setBackground(new java.awt.Color(51, 102, 255));

        titulotienda1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulotienda1.setForeground(new java.awt.Color(255, 255, 255));
        titulotienda1.setText("TIENDITA");

        javax.swing.GroupLayout fondoazuliptitulo1Layout = new javax.swing.GroupLayout(fondoazuliptitulo1);
        fondoazuliptitulo1.setLayout(fondoazuliptitulo1Layout);
        fondoazuliptitulo1Layout.setHorizontalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondoazuliptitulo1Layout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addComponent(titulotienda1)
                .addGap(45, 45, 45))
        );
        fondoazuliptitulo1Layout.setVerticalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(titulotienda1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        BG.add(fondoazuliptitulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 260, 70));

        FlechaFondo.setBackground(new java.awt.Color(234, 234, 234));
        FlechaFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha.png"))); // NOI18N
        BG.add(FlechaFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-90, 0, 380, 500));

        FlechaFondo1.setBackground(new java.awt.Color(234, 234, 234));
        FlechaFondo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha.png"))); // NOI18N
        BG.add(FlechaFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(309, 0, 490, 500));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BG, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btngestionbodegaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngestionbodegaActionPerformed
        try {
            Bodega bodega = new Bodega();
            dispose();
            bodega.setLocationRelativeTo(null);
            bodega.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MenuAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btngestionbodegaActionPerformed

    private void btngestionuser1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngestionuser1ActionPerformed
        try {
        GestionUsuarios gestionusuarios = new GestionUsuarios();
        dispose();
            gestionusuarios.setLocationRelativeTo(null);
            gestionusuarios.setVisible(true);
         } catch (ClassNotFoundException ex) {
            Logger.getLogger(MenuAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btngestionuser1ActionPerformed

    private void btngestionmarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngestionmarcaActionPerformed
        try {
            GestionMarca gestionmarca = new GestionMarca();
            dispose();
            gestionmarca.setLocationRelativeTo(null);
            gestionmarca.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MenuAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btngestionmarcaActionPerformed

    private void btngestionventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngestionventaActionPerformed
        try {
            GestionVenta venta = new GestionVenta();
            dispose();
            venta.setLocationRelativeTo(null);
            venta.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MenuAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btngestionventaActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new MenuAdmin().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MenuAdmin.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BG;
    private javax.swing.JLabel FlechaFondo;
    private javax.swing.JLabel FlechaFondo1;
    private javax.swing.JPanel bguser;
    private javax.swing.JLabel bienvenidatext;
    private javax.swing.JButton btngestionbodega;
    private javax.swing.JButton btngestionmarca;
    private javax.swing.JButton btngestionuser1;
    private javax.swing.JButton btngestionventa;
    private javax.swing.JPanel fondoazuliptitulo;
    private javax.swing.JPanel fondoazuliptitulo1;
    private javax.swing.JLabel iconoadmin;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable tablahistorial;
    private javax.swing.JLabel titulotienda;
    private javax.swing.JLabel titulotienda1;
    private javax.swing.JLabel txtnombreadmin;
    // End of variables declaration//GEN-END:variables
}
