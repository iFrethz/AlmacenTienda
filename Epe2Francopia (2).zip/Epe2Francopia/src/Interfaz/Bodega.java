package Interfaz;

import Conectar.DaoProductos;
import Clases.Productos;
import Conectar.DaoCategorias;
import Conectar.DaoMarcas;
import java.awt.Color;
import static java.lang.Integer.parseInt;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Bodega extends javax.swing.JFrame {

    DaoProductos produst = new DaoProductos();
    DaoMarcas marcadao = new DaoMarcas();
    DaoCategorias catdao = new DaoCategorias();
    Productos productsedit = new Productos();

    public Bodega() throws ClassNotFoundException {
        initComponents();
        produst.cargarTabla(tablaproductos);
        produst.cargarTabla(tablaproductos1);
        produst.cargarTabla(tablaproductos2);
        marcadao.cargarBoxMarca(boxmarcaadd);
        marcadao.cargarBoxMarca(boxmarca1);
        catdao.cargarBoxCategoria(boxcatadd);
        catdao.cargarBoxCategoria(boxcatedit);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jProgressBar1 = new javax.swing.JProgressBar();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Inventary = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaproductos1 = new javax.swing.JTable();
        trashicon = new javax.swing.JLabel();
        txtsearchinventory = new javax.swing.JTextField();
        btnsalir = new javax.swing.JLabel();
        fondoazuliptitulo3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        addproduct = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaproductos = new javax.swing.JTable();
        txtsearch = new javax.swing.JTextField();
        fondoazuliptitulo1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        BarraLateral = new javax.swing.JPanel();
        txtnombre = new javax.swing.JTextField();
        boxmarcaadd = new javax.swing.JComboBox<>();
        boxcatadd = new javax.swing.JComboBox<>();
        txtstock = new javax.swing.JTextField();
        txtstockmin = new javax.swing.JTextField();
        txtstockcrit = new javax.swing.JTextField();
        txtstockmax = new javax.swing.JTextField();
        txtprecioventa = new javax.swing.JTextField();
        txtpreciocompra = new javax.swing.JTextField();
        btnguardar = new javax.swing.JButton();
        btnsalir1 = new javax.swing.JLabel();
        flechafondo = new javax.swing.JLabel();
        EditProduct = new javax.swing.JPanel();
        trashicon1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaproductos2 = new javax.swing.JTable();
        txtsearchedit = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        fondoazuliptitulo2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        BarraLateral1 = new javax.swing.JPanel();
        txtnombreedit = new javax.swing.JTextField();
        boxmarca1 = new javax.swing.JComboBox<>();
        boxcatedit = new javax.swing.JComboBox<>();
        txtstockedit = new javax.swing.JTextField();
        txtstockminedit = new javax.swing.JTextField();
        txtstockcritedit = new javax.swing.JTextField();
        txtstockmaxedit = new javax.swing.JTextField();
        txtprecioventaedit = new javax.swing.JTextField();
        txtpreciocompraedit = new javax.swing.JTextField();
        btnguardar1 = new javax.swing.JButton();
        btnsalir2 = new javax.swing.JLabel();
        flechafondo1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 234, 234));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Inventary.setBackground(new java.awt.Color(234, 234, 234));
        Inventary.setForeground(new java.awt.Color(234, 234, 234));
        Inventary.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaproductos1.setBackground(new java.awt.Color(234, 234, 234));
        tablaproductos1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tablaproductos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Marca", "Categoria", "Stock Inicial", "Stock Mínimo", "Stock Critico", "Stock Mínimo", "Stock Máximo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaproductos1.setVerifyInputWhenFocusTarget(false);
        jScrollPane2.setViewportView(tablaproductos1);

        Inventary.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 780, 350));

        trashicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        trashicon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                trashiconMouseClicked(evt);
            }
        });
        Inventary.add(trashicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 20, -1, -1));

        txtsearchinventory.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchinventory.setForeground(new java.awt.Color(102, 102, 102));
        txtsearchinventory.setText("Ingrese un producto");
        txtsearchinventory.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchinventory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchinventoryMouseClicked(evt);
            }
        });
        txtsearchinventory.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchinventoryKeyReleased(evt);
            }
        });
        Inventary.add(txtsearchinventory, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 230, -1));

        btnsalir.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir.setText("Cerrar Sesión");
        btnsalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalirMousePressed(evt);
            }
        });
        Inventary.add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 430, -1, -1));

        fondoazuliptitulo3.setBackground(new java.awt.Color(51, 102, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("INVENTARIO");

        javax.swing.GroupLayout fondoazuliptitulo3Layout = new javax.swing.GroupLayout(fondoazuliptitulo3);
        fondoazuliptitulo3.setLayout(fondoazuliptitulo3Layout);
        fondoazuliptitulo3Layout.setHorizontalGroup(
            fondoazuliptitulo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondoazuliptitulo3Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(14, 14, 14))
        );
        fondoazuliptitulo3Layout.setVerticalGroup(
            fondoazuliptitulo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel11)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        Inventary.add(fondoazuliptitulo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 180, 70));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha.png"))); // NOI18N
        Inventary.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 0, 410, 420));

        jTabbedPane1.addTab("Inventario", Inventary);

        addproduct.setBackground(new java.awt.Color(234, 234, 234));
        addproduct.setForeground(new java.awt.Color(234, 234, 234));
        addproduct.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaproductos.setBackground(new java.awt.Color(234, 234, 234));
        tablaproductos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tablaproductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Marca", "Categoría", "Fecha Ingreso", "Precio Venta", "Precio Compra", "Stock Actual", "Stock Critico", "Stock Minimo", "Stock Maximo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaproductos.setEnabled(false);
        jScrollPane1.setViewportView(tablaproductos);

        addproduct.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, 520, 350));

        txtsearch.setBackground(new java.awt.Color(234, 234, 234));
        txtsearch.setText("Ingrese el producto");
        txtsearch.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtsearchMousePressed(evt);
            }
        });
        txtsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchKeyReleased(evt);
            }
        });
        addproduct.add(txtsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 10, 240, 40));

        fondoazuliptitulo1.setBackground(new java.awt.Color(51, 102, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("AGREGAR PRODUCTO");

        javax.swing.GroupLayout fondoazuliptitulo1Layout = new javax.swing.GroupLayout(fondoazuliptitulo1);
        fondoazuliptitulo1.setLayout(fondoazuliptitulo1Layout);
        fondoazuliptitulo1Layout.setHorizontalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addGap(0, 9, Short.MAX_VALUE))
        );
        fondoazuliptitulo1Layout.setVerticalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel9)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        addproduct.add(fondoazuliptitulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 70));

        BarraLateral.setBackground(new java.awt.Color(234, 234, 234));
        BarraLateral.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtnombre.setBackground(new java.awt.Color(234, 234, 234));
        txtnombre.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtnombre.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));
        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });

        boxmarcaadd.setBackground(new java.awt.Color(234, 234, 234));
        boxmarcaadd.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione una marca" }));
        boxmarcaadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Marca"));

        boxcatadd.setBackground(new java.awt.Color(234, 234, 234));
        boxcatadd.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione una categoría" }));
        boxcatadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Categoría"));

        txtstock.setBackground(new java.awt.Color(234, 234, 234));
        txtstock.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock"));

        txtstockmin.setBackground(new java.awt.Color(234, 234, 234));
        txtstockmin.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock Mínimo"));

        txtstockcrit.setBackground(new java.awt.Color(234, 234, 234));
        txtstockcrit.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock Crítico"));

        txtstockmax.setBackground(new java.awt.Color(234, 234, 234));
        txtstockmax.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock Máximo"));

        txtprecioventa.setBackground(new java.awt.Color(234, 234, 234));
        txtprecioventa.setBorder(javax.swing.BorderFactory.createTitledBorder("Precio Venta"));

        txtpreciocompra.setBackground(new java.awt.Color(234, 234, 234));
        txtpreciocompra.setBorder(javax.swing.BorderFactory.createTitledBorder("Precio Compra"));

        btnguardar.setBackground(new java.awt.Color(51, 102, 255));
        btnguardar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnguardar.setForeground(new java.awt.Color(255, 255, 255));
        btnguardar.setText("GUARDAR");
        btnguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout BarraLateralLayout = new javax.swing.GroupLayout(BarraLateral);
        BarraLateral.setLayout(BarraLateralLayout);
        BarraLateralLayout.setHorizontalGroup(
            BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BarraLateralLayout.createSequentialGroup()
                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BarraLateralLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btnguardar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BarraLateralLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(boxmarcaadd, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(boxcatadd, javax.swing.GroupLayout.Alignment.LEADING, 0, 230, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BarraLateralLayout.createSequentialGroup()
                                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtprecioventa, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                                    .addComponent(txtstockcrit)
                                    .addComponent(txtstock))
                                .addGap(18, 18, 18)
                                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtstockmin, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                                    .addComponent(txtstockmax)
                                    .addComponent(txtpreciocompra)))
                            .addComponent(txtnombre, javax.swing.GroupLayout.Alignment.LEADING))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        BarraLateralLayout.setVerticalGroup(
            BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarraLateralLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(boxmarcaadd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(boxcatadd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtstockmin)
                    .addComponent(txtstock))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtstockcrit)
                    .addComponent(txtstockmax))
                .addGap(18, 18, 18)
                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtpreciocompra)
                    .addComponent(txtprecioventa))
                .addGap(18, 18, 18)
                .addComponent(btnguardar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        addproduct.add(BarraLateral, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 260, 400));

        btnsalir1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir1.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir1.setText("Cerrar Sesión");
        btnsalir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalir1MousePressed(evt);
            }
        });
        addproduct.add(btnsalir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 430, -1, -1));

        flechafondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        addproduct.add(flechafondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 420));

        jTabbedPane1.addTab("Agregar Producto", addproduct);

        EditProduct.setBackground(new java.awt.Color(234, 234, 234));
        EditProduct.setForeground(new java.awt.Color(234, 234, 234));
        EditProduct.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        trashicon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        trashicon1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                trashicon1MouseClicked(evt);
            }
        });
        EditProduct.add(trashicon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, -1, -1));

        tablaproductos2.setBackground(new java.awt.Color(234, 234, 234));
        tablaproductos2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tablaproductos2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Marca", "Categoría", "Fecha Ingreso", "Precio Venta", "Precio Compra", "Stock Actual", "Stock Critico", "Stock Minimo", "Stock Maximo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaproductos2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaproductos2MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablaproductos2);

        EditProduct.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, 520, 350));

        txtsearchedit.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchedit.setText("Ingrese el producto");
        txtsearchedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtsearcheditMousePressed(evt);
            }
        });
        txtsearchedit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearcheditKeyReleased(evt);
            }
        });
        EditProduct.add(txtsearchedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 10, 240, 40));

        jButton6.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton6.setText("REGRESAR");
        EditProduct.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 470, -1, -1));

        fondoazuliptitulo2.setBackground(new java.awt.Color(51, 102, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("EDITAR PRODUCTO");

        javax.swing.GroupLayout fondoazuliptitulo2Layout = new javax.swing.GroupLayout(fondoazuliptitulo2);
        fondoazuliptitulo2.setLayout(fondoazuliptitulo2Layout);
        fondoazuliptitulo2Layout.setHorizontalGroup(
            fondoazuliptitulo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        fondoazuliptitulo2Layout.setVerticalGroup(
            fondoazuliptitulo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel10)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        EditProduct.add(fondoazuliptitulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 70));

        BarraLateral1.setBackground(new java.awt.Color(234, 234, 234));
        BarraLateral1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtnombreedit.setBackground(new java.awt.Color(234, 234, 234));
        txtnombreedit.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtnombreedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        boxmarca1.setBackground(new java.awt.Color(234, 234, 234));
        boxmarca1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione una marca" }));
        boxmarca1.setBorder(javax.swing.BorderFactory.createTitledBorder("Marca"));

        boxcatedit.setBackground(new java.awt.Color(234, 234, 234));
        boxcatedit.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione una categoría" }));
        boxcatedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Categoría"));

        txtstockedit.setBackground(new java.awt.Color(234, 234, 234));
        txtstockedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock"));

        txtstockminedit.setBackground(new java.awt.Color(234, 234, 234));
        txtstockminedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock Mínimo"));

        txtstockcritedit.setBackground(new java.awt.Color(234, 234, 234));
        txtstockcritedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock Crítico"));

        txtstockmaxedit.setBackground(new java.awt.Color(234, 234, 234));
        txtstockmaxedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Stock Máximo"));

        txtprecioventaedit.setBackground(new java.awt.Color(234, 234, 234));
        txtprecioventaedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Precio Venta"));

        txtpreciocompraedit.setBackground(new java.awt.Color(234, 234, 234));
        txtpreciocompraedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Precio Compra"));

        btnguardar1.setBackground(new java.awt.Color(51, 102, 255));
        btnguardar1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnguardar1.setForeground(new java.awt.Color(255, 255, 255));
        btnguardar1.setText("GUARDAR");
        btnguardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout BarraLateral1Layout = new javax.swing.GroupLayout(BarraLateral1);
        BarraLateral1.setLayout(BarraLateral1Layout);
        BarraLateral1Layout.setHorizontalGroup(
            BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BarraLateral1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(BarraLateral1Layout.createSequentialGroup()
                        .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtprecioventaedit, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                            .addComponent(txtstockcritedit)
                            .addComponent(txtstockedit))
                        .addGap(18, 18, 18)
                        .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtstockmaxedit)
                            .addComponent(txtstockminedit)
                            .addComponent(txtpreciocompraedit)))
                    .addComponent(boxcatedit, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(boxmarca1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
            .addGroup(BarraLateral1Layout.createSequentialGroup()
                .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BarraLateral1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txtnombreedit, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BarraLateral1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btnguardar1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        BarraLateral1Layout.setVerticalGroup(
            BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarraLateral1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(txtnombreedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(boxmarca1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(boxcatedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtstockminedit)
                    .addComponent(txtstockedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtstockcritedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstockmaxedit, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtpreciocompraedit, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtprecioventaedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(btnguardar1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        EditProduct.add(BarraLateral1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 260, 400));

        btnsalir2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir2.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir2.setText("Cerrar Sesión");
        btnsalir2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalir2MousePressed(evt);
            }
        });
        EditProduct.add(btnsalir2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 430, -1, -1));

        flechafondo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        EditProduct.add(flechafondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 420));

        jTabbedPane1.addTab("Editar Producto", EditProduct);

        jPanel1.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 500));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnguardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardar1ActionPerformed
        DaoProductos user = new DaoProductos(); //DAO

        productsedit.setNombre(txtnombreedit.getText());
        productsedit.setMarca(boxmarca1.getSelectedItem().toString());
        productsedit.setCategoria(boxcatedit.getSelectedItem().toString());
        productsedit.setStock_Inicial(Integer.parseInt(txtstockedit.getText()));
        productsedit.setStock_Minimo(Integer.parseInt(txtstockminedit.getText()));
        productsedit.setStock_Critico(Integer.parseInt(txtstockcritedit.getText()));
        productsedit.setStock_Maximo(Integer.parseInt(txtstockmaxedit.getText()));
        productsedit.setPrecio_Venta(Integer.parseInt(txtprecioventaedit.getText()));
        productsedit.setPrecio_Costo(Integer.parseInt(txtpreciocompraedit.getText()));

        try {
            user.editarProducto(productsedit);
            limpiarCamposEdit();
            produst.cargarTabla(tablaproductos);
            produst.cargarTabla(tablaproductos1);
            produst.cargarTabla(tablaproductos2);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnguardar1ActionPerformed

    private void txtsearcheditMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearcheditMousePressed
        txtsearchedit.setText("");
    }//GEN-LAST:event_txtsearcheditMousePressed

    private void btnguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarActionPerformed
        Productos productos = new Productos(); //Clase usuario
        DaoProductos user = new DaoProductos(); //DAO

        //Extracción de datos de los campos
        productos.setNombre(txtnombre.getText());
        productos.setMarca(boxmarcaadd.getSelectedItem().toString());
        productos.setCategoria(boxcatadd.getSelectedItem().toString());
        productos.setStock_Inicial(Integer.parseInt(txtstock.getText()));
        productos.setStock_Minimo(Integer.parseInt(txtstockmin.getText()));
        productos.setStock_Critico(Integer.parseInt(txtstockcrit.getText()));
        productos.setStock_Maximo(Integer.parseInt(txtstockmax.getText()));
        productos.setPrecio_Venta(Integer.parseInt(txtprecioventa.getText()));
        productos.setPrecio_Costo(Integer.parseInt(txtpreciocompra.getText()));

        try {
            user.crearProducto(productos);
            produst.cargarTabla(tablaproductos);
            produst.cargarTabla(tablaproductos1);
            produst.cargarTabla(tablaproductos2);
            limpiarCamposadd();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnguardarActionPerformed

    private void txtsearchMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchMousePressed
        txtsearch.setText("");
    }//GEN-LAST:event_txtsearchMousePressed

    private void tablaproductos2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaproductos2MouseClicked
        int fila = tablaproductos2.getSelectedRow();
        if (fila >= 0) {
            productsedit.setId(parseInt((tablaproductos2.getValueAt(fila, 0).toString()))); //Extraer la ID de la tabla  
            try {
                //Buscar al usuario seleccionado según la ID
                produst.buscaProducto(productsedit, txtnombreedit, txtstockedit, txtstockminedit, txtstockcritedit, txtstockmaxedit, txtprecioventaedit, txtpreciocompraedit);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Debe de seleccionar una fila");
        }
    }//GEN-LAST:event_tablaproductos2MouseClicked

    private void txtsearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchKeyReleased
        try {
            String buscar = txtsearch.getText();
            DaoProductos userproduct = new DaoProductos();
            userproduct.filtroProductos(buscar, tablaproductos);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchKeyReleased

    private void txtsearchinventoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchinventoryMouseClicked
        if (txtsearchinventory.getText().equals("Ingrese un producto")) {
            txtsearchinventory.setText("");
            txtsearchinventory.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtsearchinventoryMouseClicked

    private void txtsearchinventoryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchinventoryKeyReleased
        try {
            String buscar = txtsearchinventory.getText();
            DaoProductos user = new DaoProductos();
            user.filtroProductos(buscar, tablaproductos1);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchinventoryKeyReleased

    private void trashiconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trashiconMouseClicked
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de eliminar los datos?", 0, 2, null, opciones, opciones[0]);

        if (txtnombreedit.getText().isEmpty() || txtstockedit.getText().isEmpty() || txtstockminedit.getText().isEmpty() || txtstockcritedit.getText().isEmpty() || txtstockmaxedit.getText().isEmpty() || txtprecioventaedit.getText().isEmpty() || txtpreciocompraedit.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto a editar");
        } else {
            if (selection == 1) {
                DaoProductos user = new DaoProductos(); //DAO
                try {
                    user.eliminarProducto(productsedit);
                    produst.cargarTabla(tablaproductos);
                    produst.cargarTabla(tablaproductos1);
                    produst.cargarTabla(tablaproductos2);
                    limpiarCamposEdit();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_trashiconMouseClicked

    private void trashicon1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trashicon1MouseClicked
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de eliminar los datos?", 0, 2, null, opciones, opciones[0]);

        if (txtnombreedit.getText().isEmpty() || txtstockedit.getText().isEmpty() || txtstockminedit.getText().isEmpty() || txtstockcritedit.getText().isEmpty() || txtstockmaxedit.getText().isEmpty() || txtprecioventaedit.getText().isEmpty() || txtpreciocompraedit.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto a editar");
        } else {
            if (selection == 1) {
                DaoProductos user = new DaoProductos(); //DAO
                try {
                    user.eliminarProducto(productsedit);
                    produst.cargarTabla(tablaproductos);
                    produst.cargarTabla(tablaproductos1);
                    produst.cargarTabla(tablaproductos2);
                    limpiarCamposEdit();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_trashicon1MouseClicked

    private void txtsearcheditKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearcheditKeyReleased
        try {
            String buscar = txtsearch.getText();
            DaoProductos userproduct = new DaoProductos();
            userproduct.filtroProductos(buscar, tablaproductos);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearcheditKeyReleased

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed

    }//GEN-LAST:event_txtnombreActionPerformed

    private void btnsalirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalirMousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalirMousePressed

    private void btnsalir1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalir1MousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalir1MousePressed

    private void btnsalir2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalir2MousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalir2MousePressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bodega.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bodega.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bodega.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bodega.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Bodega().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Bodega.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BarraLateral;
    private javax.swing.JPanel BarraLateral1;
    private javax.swing.JPanel EditProduct;
    private javax.swing.JPanel Inventary;
    private javax.swing.JPanel addproduct;
    private javax.swing.JComboBox<String> boxcatadd;
    private javax.swing.JComboBox<String> boxcatedit;
    private javax.swing.JComboBox<String> boxmarca1;
    private javax.swing.JComboBox<String> boxmarcaadd;
    private javax.swing.JButton btnguardar;
    private javax.swing.JButton btnguardar1;
    private javax.swing.JLabel btnsalir;
    private javax.swing.JLabel btnsalir1;
    private javax.swing.JLabel btnsalir2;
    private javax.swing.JLabel flechafondo;
    private javax.swing.JLabel flechafondo1;
    private javax.swing.JPanel fondoazuliptitulo1;
    private javax.swing.JPanel fondoazuliptitulo2;
    private javax.swing.JPanel fondoazuliptitulo3;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tablaproductos;
    private javax.swing.JTable tablaproductos1;
    private javax.swing.JTable tablaproductos2;
    private javax.swing.JLabel trashicon;
    private javax.swing.JLabel trashicon1;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtnombreedit;
    private javax.swing.JTextField txtpreciocompra;
    private javax.swing.JTextField txtpreciocompraedit;
    private javax.swing.JTextField txtprecioventa;
    private javax.swing.JTextField txtprecioventaedit;
    private javax.swing.JTextField txtsearch;
    private javax.swing.JTextField txtsearchedit;
    private javax.swing.JTextField txtsearchinventory;
    private javax.swing.JTextField txtstock;
    private javax.swing.JTextField txtstockcrit;
    private javax.swing.JTextField txtstockcritedit;
    private javax.swing.JTextField txtstockedit;
    private javax.swing.JTextField txtstockmax;
    private javax.swing.JTextField txtstockmaxedit;
    private javax.swing.JTextField txtstockmin;
    private javax.swing.JTextField txtstockminedit;
    // End of variables declaration//GEN-END:variables

    private void limpiarCamposadd() {
        txtnombre.setText("");
        txtstock.setText("");
        txtstockmin.setText("");
        txtstockcrit.setText("");
        txtstockmax.setText("");
        txtprecioventa.setText("");
        txtpreciocompra.setText("");
    }

    private void limpiarCamposEdit() {
        txtnombreedit.setText("");
        txtstockedit.setText("");
        txtstockminedit.setText("");
        txtstockcritedit.setText("");
        txtstockmaxedit.setText("");
        txtprecioventaedit.setText("");
        txtpreciocompraedit.setText("");
    }
}
