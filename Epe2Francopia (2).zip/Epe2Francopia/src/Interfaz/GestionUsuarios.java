package Interfaz;

import Clases.Cliente;
import Clases.Usuarios;

import Conectar.DaoCliente;
import Conectar.DaoUsuarios;
import java.awt.Color;
import static java.lang.Integer.parseInt;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GestionUsuarios extends javax.swing.JFrame {
    
    DaoCliente dclient = new DaoCliente();
    DaoUsuarios users = new DaoUsuarios();
    Usuarios usuarioedit = new Usuarios();
    Cliente clientedit = new Cliente();
    
    public GestionUsuarios() throws ClassNotFoundException {
        initComponents();
        users.cargarTabla(tablausuarios);
        users.cargarTabla(tablausuarios1);
        users.cargarTabla(tablausuarios2);
        dclient.cargarTabla(tablacliente);
        dclient.cargarTabla(tablacliente1);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Menucliente = new javax.swing.JTabbedPane();
        Listado_usuarios_panel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablausuarios = new javax.swing.JTable();
        btnsalir2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnvolverflecha = new javax.swing.JLabel();
        txtsearchmenuser1 = new javax.swing.JTextField();
        AddUser = new javax.swing.JPanel();
        adduser = new javax.swing.JPanel();
        txtsearchadduser = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablausuarios1 = new javax.swing.JTable();
        btnvolverflecha1 = new javax.swing.JLabel();
        fondoazuliptitulo1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        BarraLateral = new javax.swing.JPanel();
        txtnombreuseradd = new javax.swing.JTextField();
        boxRolUser = new javax.swing.JComboBox<>();
        txttelefonouser = new javax.swing.JTextField();
        txtcontraseñauseradd = new javax.swing.JTextField();
        btnguardarusernew = new javax.swing.JButton();
        txtrutadd = new javax.swing.JTextField();
        txtdigitadorrutadd = new javax.swing.JTextField();
        textsearch = new javax.swing.JLabel();
        btnsalir = new javax.swing.JLabel();
        Edittrabajador = new javax.swing.JPanel();
        Edituser = new javax.swing.JPanel();
        trashicon1 = new javax.swing.JLabel();
        txtsearchedituser = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablausuarios2 = new javax.swing.JTable();
        btnvolverflecha2 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        fondoazuliptitulo2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtnombreuseredit = new javax.swing.JTextField();
        boxRolUserEdit = new javax.swing.JComboBox<>();
        txttelefonouseredit = new javax.swing.JTextField();
        txtcontraseñauseredit = new javax.swing.JTextField();
        btnguardarusernew1 = new javax.swing.JButton();
        txtrutedit = new javax.swing.JTextField();
        txtdigitadorrutedit = new javax.swing.JTextField();
        textsearch4 = new javax.swing.JLabel();
        btnsalir1 = new javax.swing.JLabel();
        addcliente = new javax.swing.JPanel();
        addclient = new javax.swing.JPanel();
        txtsearchadduser1 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablacliente = new javax.swing.JTable();
        btnvolverflecha3 = new javax.swing.JLabel();
        fondoazuliptitulo3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        BarraLateral1 = new javax.swing.JPanel();
        txtclientadd = new javax.swing.JTextField();
        txtclienttelefonoadd = new javax.swing.JTextField();
        txtclientinteresadd = new javax.swing.JTextField();
        btnguardarusernew2 = new javax.swing.JButton();
        txtclientdirectadd = new javax.swing.JTextField();
        textsearch1 = new javax.swing.JLabel();
        btnsalir3 = new javax.swing.JLabel();
        EditarCliente = new javax.swing.JPanel();
        editclient = new javax.swing.JPanel();
        trashicon2 = new javax.swing.JLabel();
        txtsearchadduser2 = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablacliente1 = new javax.swing.JTable();
        btnvolverflecha4 = new javax.swing.JLabel();
        fondoazuliptitulo4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        BarraLateral2 = new javax.swing.JPanel();
        txtclientedit = new javax.swing.JTextField();
        txtclienttelefonoedit = new javax.swing.JTextField();
        txtclientinteresedit = new javax.swing.JTextField();
        btnguardarusernew3 = new javax.swing.JButton();
        txtclientdirectedit = new javax.swing.JTextField();
        textsearch2 = new javax.swing.JLabel();
        btnsalir4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Listado_usuarios_panel.setBackground(new java.awt.Color(234, 234, 234));
        Listado_usuarios_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablausuarios.setBackground(new java.awt.Color(242, 242, 242));
        tablausuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Role", "Teléfono", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablausuarios);

        Listado_usuarios_panel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 710, 370));

        btnsalir2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir2.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir2.setText("Cerrar Sesión");
        btnsalir2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalir2MousePressed(evt);
            }
        });
        Listado_usuarios_panel.add(btnsalir2, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 20, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        Listado_usuarios_panel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 800, 410));

        btnvolverflecha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflechaMousePressed(evt);
            }
        });
        Listado_usuarios_panel.add(btnvolverflecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        txtsearchmenuser1.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchmenuser1.setForeground(new java.awt.Color(102, 102, 102));
        txtsearchmenuser1.setText("Ingrese un usuario/rol");
        txtsearchmenuser1.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchmenuser1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchmenuser1MouseClicked(evt);
            }
        });
        txtsearchmenuser1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchmenuser1KeyReleased(evt);
            }
        });
        Listado_usuarios_panel.add(txtsearchmenuser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, 180, -1));

        Menucliente.addTab("Listado De Usuarios", Listado_usuarios_panel);

        adduser.setBackground(new java.awt.Color(234, 234, 234));
        adduser.setForeground(new java.awt.Color(234, 234, 234));
        adduser.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtsearchadduser.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchadduser.setForeground(new java.awt.Color(102, 102, 102));
        txtsearchadduser.setText("Ingrese un usuario/rol");
        txtsearchadduser.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchadduser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchadduserMouseClicked(evt);
            }
        });
        txtsearchadduser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchadduserKeyReleased(evt);
            }
        });
        adduser.add(txtsearchadduser, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 210, -1));

        tablausuarios1.setBackground(new java.awt.Color(242, 242, 242));
        tablausuarios1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Role", "Correo", "Teléfono"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tablausuarios1);

        adduser.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 500, 360));

        btnvolverflecha1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflecha1MousePressed(evt);
            }
        });
        adduser.add(btnvolverflecha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        fondoazuliptitulo1.setBackground(new java.awt.Color(51, 102, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("AGREGAR TRABAJADOR");

        javax.swing.GroupLayout fondoazuliptitulo1Layout = new javax.swing.GroupLayout(fondoazuliptitulo1);
        fondoazuliptitulo1.setLayout(fondoazuliptitulo1Layout);
        fondoazuliptitulo1Layout.setHorizontalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel9)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        fondoazuliptitulo1Layout.setVerticalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel9)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        adduser.add(fondoazuliptitulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 70));

        BarraLateral.setBackground(new java.awt.Color(234, 234, 234));
        BarraLateral.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtnombreuseradd.setBackground(new java.awt.Color(234, 234, 234));
        txtnombreuseradd.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtnombreuseradd.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        boxRolUser.setBackground(new java.awt.Color(234, 234, 234));
        boxRolUser.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---------", "Admin", "Empleado" }));
        boxRolUser.setBorder(javax.swing.BorderFactory.createTitledBorder("Rol"));

        txttelefonouser.setBackground(new java.awt.Color(234, 234, 234));
        txttelefonouser.setBorder(javax.swing.BorderFactory.createTitledBorder("Teléfono"));

        txtcontraseñauseradd.setBackground(new java.awt.Color(234, 234, 234));
        txtcontraseñauseradd.setBorder(javax.swing.BorderFactory.createTitledBorder("Contraseña"));

        btnguardarusernew.setBackground(new java.awt.Color(51, 102, 255));
        btnguardarusernew.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnguardarusernew.setForeground(new java.awt.Color(255, 255, 255));
        btnguardarusernew.setText("GUARDAR");
        btnguardarusernew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarusernewActionPerformed(evt);
            }
        });

        txtrutadd.setBackground(new java.awt.Color(234, 234, 234));
        txtrutadd.setBorder(javax.swing.BorderFactory.createTitledBorder("RUT"));

        txtdigitadorrutadd.setBackground(new java.awt.Color(234, 234, 234));
        txtdigitadorrutadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Digitador"));

        javax.swing.GroupLayout BarraLateralLayout = new javax.swing.GroupLayout(BarraLateral);
        BarraLateral.setLayout(BarraLateralLayout);
        BarraLateralLayout.setHorizontalGroup(
            BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BarraLateralLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnguardarusernew, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(BarraLateralLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtnombreuseradd, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(txtcontraseñauseradd, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txttelefonouser)
                    .addComponent(boxRolUser, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarraLateralLayout.createSequentialGroup()
                        .addComponent(txtrutadd, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(txtdigitadorrutadd, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        BarraLateralLayout.setVerticalGroup(
            BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarraLateralLayout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(txtnombreuseradd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(BarraLateralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtrutadd, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtdigitadorrutadd, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(boxRolUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(txttelefonouser, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtcontraseñauseradd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(btnguardarusernew, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        adduser.add(BarraLateral, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 260, 400));

        textsearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        adduser.add(textsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 750, 420));

        btnsalir.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir.setText("Cerrar Sesión");
        btnsalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalirMousePressed(evt);
            }
        });
        adduser.add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 430, -1, -1));

        javax.swing.GroupLayout AddUserLayout = new javax.swing.GroupLayout(AddUser);
        AddUser.setLayout(AddUserLayout);
        AddUserLayout.setHorizontalGroup(
            AddUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(AddUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(AddUserLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(adduser, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        AddUserLayout.setVerticalGroup(
            AddUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
            .addGroup(AddUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(AddUserLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(adduser, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Menucliente.addTab("Agregar Trabajador", AddUser);

        Edituser.setBackground(new java.awt.Color(234, 234, 234));
        Edituser.setForeground(new java.awt.Color(234, 234, 234));
        Edituser.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        trashicon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        trashicon1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                trashicon1MouseClicked(evt);
            }
        });
        Edituser.add(trashicon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, -1, -1));

        txtsearchedituser.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchedituser.setForeground(new java.awt.Color(102, 102, 102));
        txtsearchedituser.setText("Ingrese un usuario/rol");
        txtsearchedituser.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchedituser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchedituserMouseClicked(evt);
            }
        });
        txtsearchedituser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchedituserKeyReleased(evt);
            }
        });
        Edituser.add(txtsearchedituser, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 210, -1));

        tablausuarios2.setBackground(new java.awt.Color(242, 242, 242));
        tablausuarios2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Role", "Correo", "Teléfono"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablausuarios2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablausuarios2MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablausuarios2);

        Edituser.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 500, 360));

        btnvolverflecha2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflecha2MousePressed(evt);
            }
        });
        Edituser.add(btnvolverflecha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        jButton6.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton6.setText("REGRESAR");
        Edituser.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 470, -1, -1));

        fondoazuliptitulo2.setBackground(new java.awt.Color(51, 102, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("EDITAR TRABAJADOR");

        javax.swing.GroupLayout fondoazuliptitulo2Layout = new javax.swing.GroupLayout(fondoazuliptitulo2);
        fondoazuliptitulo2.setLayout(fondoazuliptitulo2Layout);
        fondoazuliptitulo2Layout.setHorizontalGroup(
            fondoazuliptitulo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel10)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        fondoazuliptitulo2Layout.setVerticalGroup(
            fondoazuliptitulo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel10)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        Edituser.add(fondoazuliptitulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 70));

        jPanel4.setBackground(new java.awt.Color(234, 234, 234));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtnombreuseredit.setBackground(new java.awt.Color(234, 234, 234));
        txtnombreuseredit.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtnombreuseredit.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        boxRolUserEdit.setBackground(new java.awt.Color(234, 234, 234));
        boxRolUserEdit.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-----------------", "Admin", "Empleado" }));
        boxRolUserEdit.setBorder(javax.swing.BorderFactory.createTitledBorder("Rol"));

        txttelefonouseredit.setBackground(new java.awt.Color(234, 234, 234));
        txttelefonouseredit.setBorder(javax.swing.BorderFactory.createTitledBorder("Teléfono"));

        txtcontraseñauseredit.setBackground(new java.awt.Color(234, 234, 234));
        txtcontraseñauseredit.setBorder(javax.swing.BorderFactory.createTitledBorder("Contraseña"));

        btnguardarusernew1.setBackground(new java.awt.Color(51, 102, 255));
        btnguardarusernew1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnguardarusernew1.setForeground(new java.awt.Color(255, 255, 255));
        btnguardarusernew1.setText("GUARDAR");
        btnguardarusernew1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarusernew1ActionPerformed(evt);
            }
        });

        txtrutedit.setBackground(new java.awt.Color(234, 234, 234));
        txtrutedit.setBorder(javax.swing.BorderFactory.createTitledBorder("RUT"));

        txtdigitadorrutedit.setBackground(new java.awt.Color(234, 234, 234));
        txtdigitadorrutedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Digitador"));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnguardarusernew1, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(txtrutedit, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(txtdigitadorrutedit, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(boxRolUserEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtnombreuseredit, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txttelefonouseredit, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcontraseñauseredit, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(txtnombreuseredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtrutedit, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtdigitadorrutedit, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(boxRolUserEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txttelefonouseredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtcontraseñauseredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(btnguardarusernew1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        Edituser.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 260, 400));

        textsearch4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        Edituser.add(textsearch4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 750, 420));

        btnsalir1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir1.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir1.setText("Cerrar Sesión");
        btnsalir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalir1MousePressed(evt);
            }
        });
        Edituser.add(btnsalir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 430, -1, -1));

        javax.swing.GroupLayout EdittrabajadorLayout = new javax.swing.GroupLayout(Edittrabajador);
        Edittrabajador.setLayout(EdittrabajadorLayout);
        EdittrabajadorLayout.setHorizontalGroup(
            EdittrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(EdittrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(EdittrabajadorLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Edituser, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        EdittrabajadorLayout.setVerticalGroup(
            EdittrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
            .addGroup(EdittrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(EdittrabajadorLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Edituser, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Menucliente.addTab("Editar Trabajador", Edittrabajador);

        addclient.setBackground(new java.awt.Color(234, 234, 234));
        addclient.setForeground(new java.awt.Color(234, 234, 234));
        addclient.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtsearchadduser1.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchadduser1.setForeground(new java.awt.Color(102, 102, 102));
        txtsearchadduser1.setText("Ingrese un usuario/rol");
        txtsearchadduser1.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchadduser1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchadduser1MouseClicked(evt);
            }
        });
        txtsearchadduser1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchadduser1KeyReleased(evt);
            }
        });
        addclient.add(txtsearchadduser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 210, -1));

        tablacliente.setBackground(new java.awt.Color(242, 242, 242));
        tablacliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Dirección", "Teléfono", "Tarifa"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(tablacliente);

        addclient.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 500, 360));

        btnvolverflecha3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflecha3MousePressed(evt);
            }
        });
        addclient.add(btnvolverflecha3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        fondoazuliptitulo3.setBackground(new java.awt.Color(51, 102, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("AGREGAR CLIENTE");

        javax.swing.GroupLayout fondoazuliptitulo3Layout = new javax.swing.GroupLayout(fondoazuliptitulo3);
        fondoazuliptitulo3.setLayout(fondoazuliptitulo3Layout);
        fondoazuliptitulo3Layout.setHorizontalGroup(
            fondoazuliptitulo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo3Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel11)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        fondoazuliptitulo3Layout.setVerticalGroup(
            fondoazuliptitulo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel11)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        addclient.add(fondoazuliptitulo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 70));

        BarraLateral1.setBackground(new java.awt.Color(234, 234, 234));
        BarraLateral1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtclientadd.setBackground(new java.awt.Color(234, 234, 234));
        txtclientadd.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtclientadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtclienttelefonoadd.setBackground(new java.awt.Color(234, 234, 234));
        txtclienttelefonoadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Teléfono"));

        txtclientinteresadd.setBackground(new java.awt.Color(234, 234, 234));
        txtclientinteresadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Interes"));

        btnguardarusernew2.setBackground(new java.awt.Color(51, 102, 255));
        btnguardarusernew2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnguardarusernew2.setForeground(new java.awt.Color(255, 255, 255));
        btnguardarusernew2.setText("GUARDAR");
        btnguardarusernew2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarusernew2ActionPerformed(evt);
            }
        });

        txtclientdirectadd.setBackground(new java.awt.Color(234, 234, 234));
        txtclientdirectadd.setBorder(javax.swing.BorderFactory.createTitledBorder("Dirección"));

        javax.swing.GroupLayout BarraLateral1Layout = new javax.swing.GroupLayout(BarraLateral1);
        BarraLateral1.setLayout(BarraLateral1Layout);
        BarraLateral1Layout.setHorizontalGroup(
            BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BarraLateral1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnguardarusernew2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(BarraLateral1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtclientadd, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(txtclientinteresadd, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtclienttelefonoadd)
                    .addComponent(txtclientdirectadd))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        BarraLateral1Layout.setVerticalGroup(
            BarraLateral1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarraLateral1Layout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addComponent(txtclientadd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtclientdirectadd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtclienttelefonoadd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtclientinteresadd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(btnguardarusernew2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        addclient.add(BarraLateral1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 260, 400));

        textsearch1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        addclient.add(textsearch1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 750, 420));

        btnsalir3.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir3.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir3.setText("Cerrar Sesión");
        btnsalir3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalir3MousePressed(evt);
            }
        });
        addclient.add(btnsalir3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 430, -1, -1));

        javax.swing.GroupLayout addclienteLayout = new javax.swing.GroupLayout(addcliente);
        addcliente.setLayout(addclienteLayout);
        addclienteLayout.setHorizontalGroup(
            addclienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(addclienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addclienteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(addclient, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        addclienteLayout.setVerticalGroup(
            addclienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
            .addGroup(addclienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addclienteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(addclient, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Menucliente.addTab("Agregar Cliente", addcliente);

        editclient.setBackground(new java.awt.Color(234, 234, 234));
        editclient.setForeground(new java.awt.Color(234, 234, 234));
        editclient.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        trashicon2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        trashicon2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                trashicon2MouseClicked(evt);
            }
        });
        editclient.add(trashicon2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, -1, -1));

        txtsearchadduser2.setBackground(new java.awt.Color(234, 234, 234));
        txtsearchadduser2.setForeground(new java.awt.Color(102, 102, 102));
        txtsearchadduser2.setText("Ingrese un usuario/rol");
        txtsearchadduser2.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar"));
        txtsearchadduser2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchadduser2MouseClicked(evt);
            }
        });
        txtsearchadduser2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchadduser2KeyReleased(evt);
            }
        });
        editclient.add(txtsearchadduser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 210, -1));

        tablacliente1.setBackground(new java.awt.Color(242, 242, 242));
        tablacliente1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Dirección", "Teléfono", "Interes"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablacliente1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablacliente1MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tablacliente1);

        editclient.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 500, 360));

        btnvolverflecha4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflecha4MousePressed(evt);
            }
        });
        editclient.add(btnvolverflecha4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        fondoazuliptitulo4.setBackground(new java.awt.Color(51, 102, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("AGREGAR CLIENTE");

        javax.swing.GroupLayout fondoazuliptitulo4Layout = new javax.swing.GroupLayout(fondoazuliptitulo4);
        fondoazuliptitulo4.setLayout(fondoazuliptitulo4Layout);
        fondoazuliptitulo4Layout.setHorizontalGroup(
            fondoazuliptitulo4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel12)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        fondoazuliptitulo4Layout.setVerticalGroup(
            fondoazuliptitulo4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel12)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        editclient.add(fondoazuliptitulo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 70));

        BarraLateral2.setBackground(new java.awt.Color(234, 234, 234));
        BarraLateral2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtclientedit.setBackground(new java.awt.Color(234, 234, 234));
        txtclientedit.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtclientedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtclienttelefonoedit.setBackground(new java.awt.Color(234, 234, 234));
        txtclienttelefonoedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Teléfono"));

        txtclientinteresedit.setBackground(new java.awt.Color(234, 234, 234));
        txtclientinteresedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Interes"));

        btnguardarusernew3.setBackground(new java.awt.Color(51, 102, 255));
        btnguardarusernew3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnguardarusernew3.setForeground(new java.awt.Color(255, 255, 255));
        btnguardarusernew3.setText("GUARDAR");
        btnguardarusernew3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarusernew3ActionPerformed(evt);
            }
        });

        txtclientdirectedit.setBackground(new java.awt.Color(234, 234, 234));
        txtclientdirectedit.setBorder(javax.swing.BorderFactory.createTitledBorder("Dirección"));

        javax.swing.GroupLayout BarraLateral2Layout = new javax.swing.GroupLayout(BarraLateral2);
        BarraLateral2.setLayout(BarraLateral2Layout);
        BarraLateral2Layout.setHorizontalGroup(
            BarraLateral2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BarraLateral2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnguardarusernew3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(BarraLateral2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(BarraLateral2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtclientedit, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(txtclientinteresedit, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtclienttelefonoedit)
                    .addComponent(txtclientdirectedit))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        BarraLateral2Layout.setVerticalGroup(
            BarraLateral2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarraLateral2Layout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addComponent(txtclientedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtclientdirectedit, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtclienttelefonoedit, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtclientinteresedit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(btnguardarusernew3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        editclient.add(BarraLateral2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 260, 400));

        textsearch2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        editclient.add(textsearch2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 750, 420));

        btnsalir4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        btnsalir4.setForeground(new java.awt.Color(0, 0, 153));
        btnsalir4.setText("Cerrar Sesión");
        btnsalir4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnsalir4MousePressed(evt);
            }
        });
        editclient.add(btnsalir4, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 430, -1, -1));

        javax.swing.GroupLayout EditarClienteLayout = new javax.swing.GroupLayout(EditarCliente);
        EditarCliente.setLayout(EditarClienteLayout);
        EditarClienteLayout.setHorizontalGroup(
            EditarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(EditarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(EditarClienteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(editclient, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        EditarClienteLayout.setVerticalGroup(
            EditarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
            .addGroup(EditarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(EditarClienteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(editclient, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Menucliente.addTab("Editar Cliente", EditarCliente);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Menucliente)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Menucliente, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnguardarusernewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarusernewActionPerformed
        Usuarios usuario = new Usuarios(); //Clase usuario
        DaoUsuarios user = new DaoUsuarios(); //DAO

        //Extracción de datos de los campos
        usuario.setName(txtnombreuseradd.getText());
        usuario.setRut(Integer.parseInt(txtrutadd.getText()));
        usuario.setDv(Integer.parseInt(txtdigitadorrutadd.getText()));
        usuario.setRol(boxRolUser.getSelectedItem().toString());
        usuario.setPassword(txtcontraseñauseradd.getText());
        usuario.setTelefono(txttelefonouser.getText());

        try {
            user.crearUsuario(usuario);
            users.cargarTabla(tablausuarios);
            users.cargarTabla(tablausuarios1);
            users.cargarTabla(tablausuarios2);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(GestionUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnguardarusernewActionPerformed

    private void btnvolverflechaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflechaMousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflechaMousePressed

    private void btnvolverflecha1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflecha1MousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflecha1MousePressed

    private void txtsearchadduserKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchadduserKeyReleased
        try {
            String buscar = txtsearchadduser.getText();
            DaoUsuarios user = new DaoUsuarios();
            user.filtroUsuarios(buscar, tablausuarios1);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchadduserKeyReleased

    private void txtsearchadduserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchadduserMouseClicked
        if (txtsearchadduser.getText().equals("Ingrese un usuario/rol")) {
            txtsearchadduser.setText("");
            txtsearchadduser.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtsearchadduserMouseClicked

    private void txtsearchmenuser1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchmenuser1MouseClicked
        if (txtsearchmenuser1.getText().equals("Ingrese un usuario/rol")) {
            txtsearchmenuser1.setText("");
            txtsearchmenuser1.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtsearchmenuser1MouseClicked

    private void txtsearchmenuser1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchmenuser1KeyReleased
        try {
            String buscar = txtsearchmenuser1.getText();
            DaoUsuarios user = new DaoUsuarios();
            user.filtroUsuarios(buscar, tablausuarios);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchmenuser1KeyReleased

    private void txtsearchedituserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchedituserMouseClicked
        if (txtsearchadduser.getText().equals("Ingrese un usuario/rol")) {
            txtsearchadduser.setText("");
            txtsearchadduser.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtsearchedituserMouseClicked

    private void txtsearchedituserKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchedituserKeyReleased
        try {
            String buscar = txtsearchedituser.getText();
            DaoUsuarios user = new DaoUsuarios();
            user.filtroUsuarios(buscar, tablausuarios);
            user.filtroUsuarios(buscar, tablausuarios1);
            user.filtroUsuarios(buscar, tablausuarios2);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchedituserKeyReleased

    private void btnvolverflecha2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflecha2MousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflecha2MousePressed

    private void btnguardarusernew1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarusernew1ActionPerformed
        DaoUsuarios user = new DaoUsuarios(); //DAO

        usuarioedit.setName(txtnombreuseredit.getText());
        usuarioedit.setRut(Integer.parseInt(txtrutedit.getText()));
        usuarioedit.setDv(Integer.parseInt(txtdigitadorrutedit.getText()));
        usuarioedit.setRol(boxRolUserEdit.getSelectedItem().toString());
        usuarioedit.setPassword(txtcontraseñauseredit.getText());
        usuarioedit.setTelefono(txttelefonouseredit.getText());

        try {
            user.editarUsuario(usuarioedit);
            limpiarCamposEdit();
            users.cargarTabla(tablausuarios);
            users.cargarTabla(tablausuarios1);
            users.cargarTabla(tablausuarios2);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnguardarusernew1ActionPerformed

    private void tablausuarios2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablausuarios2MouseClicked
        int fila = tablausuarios2.getSelectedRow();
        if (fila >= 0) {
            usuarioedit.setId(parseInt((tablausuarios2.getValueAt(fila, 0).toString()))); //Extraer la ID de la tabla  
            try {
                users.buscaUsuarios(usuarioedit, txtnombreuseredit, txtrutedit, txtdigitadorrutedit, boxRolUserEdit, txtcontraseñauseredit, txttelefonouseredit);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
        }
    }//GEN-LAST:event_tablausuarios2MouseClicked

    private void trashicon1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trashicon1MouseClicked
        String[] opciones = { "Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de eliminar los datos?",  0, 2, null, opciones, opciones[0]);

        if(txtnombreuseredit.getText().isEmpty() || txtrutedit.getText().isEmpty() ||  txtdigitadorrutedit.getText().isEmpty() || boxRolUserEdit.getSelectedIndex() == -1 || txtcontraseñauseredit.getText().isEmpty() || txttelefonouseredit.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Seleccione un usuario a editar");
        }else{
            if (selection == 1) {
                DaoUsuarios user = new DaoUsuarios(); //DAO
                try {
                    user.eliminarUsuario(usuarioedit);
                    users.cargarTabla(tablausuarios);
                    users.cargarTabla(tablausuarios1);
                    users.cargarTabla(tablausuarios2);
                    limpiarCamposEdit();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_trashicon1MouseClicked

    private void btnsalirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalirMousePressed
        String[] opciones = { "Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?",  0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalirMousePressed

    private void btnsalir1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalir1MousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalir1MousePressed

    private void btnsalir2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalir2MousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalir2MousePressed

    private void txtsearchadduser1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchadduser1MouseClicked
        if (txtsearchadduser.getText().equals("Ingrese un usuario/rol")) {
            txtsearchadduser.setText("");
            txtsearchadduser.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtsearchadduser1MouseClicked

    private void txtsearchadduser1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchadduser1KeyReleased
        try {
            String buscar = txtsearchadduser1.getText();
            DaoCliente clients = new DaoCliente();
            clients.filtroCliente(buscar, tablacliente);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchadduser1KeyReleased

    private void btnvolverflecha3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflecha3MousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflecha3MousePressed

    private void btnguardarusernew2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarusernew2ActionPerformed
        Cliente client = new Cliente(); //Clase usuario
        DaoCliente dclient = new DaoCliente(); //DAO

        client.setNombre(txtclientadd.getText());
        client.setDireccion(txtclientdirectadd.getText());
        client.setTelefono(txtclienttelefonoadd.getText());
        client.setInteres(Float.parseFloat(txtclientinteresadd.getText()));

        try {
            dclient.crearCliente(client);
            dclient.cargarTabla(tablacliente);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(GestionUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnguardarusernew2ActionPerformed

    private void btnsalir3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalir3MousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalir3MousePressed

    private void txtsearchadduser2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchadduser2MouseClicked
        if (txtsearchadduser.getText().equals("Ingrese un usuario/rol")) {
            txtsearchadduser.setText("");
            txtsearchadduser.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtsearchadduser2MouseClicked

    private void txtsearchadduser2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchadduser2KeyReleased
        try {
            String buscar = txtsearchadduser2.getText();
            DaoCliente clients = new DaoCliente();
            clients.filtroCliente(buscar, tablacliente);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtsearchadduser2KeyReleased

    private void btnvolverflecha4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflecha4MousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflecha4MousePressed

    private void btnguardarusernew3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarusernew3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnguardarusernew3ActionPerformed

    private void btnsalir4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsalir4MousePressed
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de cerrar sesión?", 0, 2, null, opciones, opciones[0]);

        if (selection == 1) {
            Login login = new Login();
            dispose();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        }
    }//GEN-LAST:event_btnsalir4MousePressed

    private void trashicon2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trashicon2MouseClicked
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de eliminar los datos?", 0, 2, null, opciones, opciones[0]);

        if (txtclientedit.getText().isEmpty() || txtclientdirectedit.getText().isEmpty() || txtclienttelefonoedit.getText().isEmpty() || txtclientinteresedit.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente a editar");
        } else {
            if (selection == 1) {
                DaoCliente clientd = new DaoCliente(); //DAO
                try {
                    clientd.eliminarCliente(clientedit);
                    dclient.cargarTabla(tablacliente);
                    dclient.cargarTabla(tablacliente1);
                    limpiarCamposEdit();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_trashicon2MouseClicked

    private void tablacliente1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablacliente1MouseClicked
        int fila = tablacliente1.getSelectedRow();
        if (fila >= 0) {
            int id = parseInt((tablacliente1.getValueAt(fila, 0).toString()));
            try {
                dclient.buscaCliente(id, txtclientedit, txtclientdirectedit, txtclienttelefonoedit, txtclientinteresedit);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
        }
    }//GEN-LAST:event_tablacliente1MouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new GestionUsuarios().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AddUser;
    private javax.swing.JPanel BarraLateral;
    private javax.swing.JPanel BarraLateral1;
    private javax.swing.JPanel BarraLateral2;
    private javax.swing.JPanel EditarCliente;
    private javax.swing.JPanel Edittrabajador;
    private javax.swing.JPanel Edituser;
    private javax.swing.JPanel Listado_usuarios_panel;
    private javax.swing.JTabbedPane Menucliente;
    private javax.swing.JPanel addclient;
    private javax.swing.JPanel addcliente;
    private javax.swing.JPanel adduser;
    private javax.swing.JComboBox<String> boxRolUser;
    private javax.swing.JComboBox<String> boxRolUserEdit;
    private javax.swing.JButton btnguardarusernew;
    private javax.swing.JButton btnguardarusernew1;
    private javax.swing.JButton btnguardarusernew2;
    private javax.swing.JButton btnguardarusernew3;
    private javax.swing.JLabel btnsalir;
    private javax.swing.JLabel btnsalir1;
    private javax.swing.JLabel btnsalir2;
    private javax.swing.JLabel btnsalir3;
    private javax.swing.JLabel btnsalir4;
    private javax.swing.JLabel btnvolverflecha;
    private javax.swing.JLabel btnvolverflecha1;
    private javax.swing.JLabel btnvolverflecha2;
    private javax.swing.JLabel btnvolverflecha3;
    private javax.swing.JLabel btnvolverflecha4;
    private javax.swing.JPanel editclient;
    private javax.swing.JPanel fondoazuliptitulo1;
    private javax.swing.JPanel fondoazuliptitulo2;
    private javax.swing.JPanel fondoazuliptitulo3;
    private javax.swing.JPanel fondoazuliptitulo4;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable tablacliente;
    private javax.swing.JTable tablacliente1;
    private javax.swing.JTable tablausuarios;
    private javax.swing.JTable tablausuarios1;
    private javax.swing.JTable tablausuarios2;
    private javax.swing.JLabel textsearch;
    private javax.swing.JLabel textsearch1;
    private javax.swing.JLabel textsearch2;
    private javax.swing.JLabel textsearch4;
    private javax.swing.JLabel trashicon1;
    private javax.swing.JLabel trashicon2;
    private javax.swing.JTextField txtclientadd;
    private javax.swing.JTextField txtclientdirectadd;
    private javax.swing.JTextField txtclientdirectedit;
    private javax.swing.JTextField txtclientedit;
    private javax.swing.JTextField txtclientinteresadd;
    private javax.swing.JTextField txtclientinteresedit;
    private javax.swing.JTextField txtclienttelefonoadd;
    private javax.swing.JTextField txtclienttelefonoedit;
    private javax.swing.JTextField txtcontraseñauseradd;
    private javax.swing.JTextField txtcontraseñauseredit;
    private javax.swing.JTextField txtdigitadorrutadd;
    private javax.swing.JTextField txtdigitadorrutedit;
    private javax.swing.JTextField txtnombreuseradd;
    private javax.swing.JTextField txtnombreuseredit;
    private javax.swing.JTextField txtrutadd;
    private javax.swing.JTextField txtrutedit;
    private javax.swing.JTextField txtsearchadduser;
    private javax.swing.JTextField txtsearchadduser1;
    private javax.swing.JTextField txtsearchadduser2;
    private javax.swing.JTextField txtsearchedituser;
    private javax.swing.JTextField txtsearchmenuser1;
    private javax.swing.JTextField txttelefonouser;
    private javax.swing.JTextField txttelefonouseredit;
    // End of variables declaration//GEN-END:variables
    
    private void limpiarCamposEdit() {
        txtnombreuseredit.setText("");
        txtrutedit.setText("");
        txtdigitadorrutedit.setText("");
        boxRolUserEdit.setSelectedItem(null);
        txtcontraseñauseredit.setText("");
        txttelefonouseredit.setText("");
    }

}
