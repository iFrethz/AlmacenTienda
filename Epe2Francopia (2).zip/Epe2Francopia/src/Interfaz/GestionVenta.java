package Interfaz;

import Clases.Productos;
import Conectar.DaoProductos;
import Conectar.DaoVenta;
import static java.lang.Integer.parseInt;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GestionVenta extends javax.swing.JFrame {

    DaoVenta dventa = new DaoVenta();
    Productos productsID = new Productos();

    public GestionVenta() throws ClassNotFoundException {
        initComponents();
        dventa.cargarTabla(listaproductos);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        fondoazuliptitulo = new javax.swing.JPanel();
        IPTITULO = new javax.swing.JLabel();
        btnvolverflecha2 = new javax.swing.JLabel();
        bgsesion = new javax.swing.JPanel();
        tztsearchlist = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaproductos = new javax.swing.JTable();
        preciototal = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        clienteproductos = new javax.swing.JTable();
        btnvender = new javax.swing.JToggleButton();
        tztcliente1 = new javax.swing.JTextField();
        intereslabel = new javax.swing.JLabel();
        imgflechafondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(234, 234, 234));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fondoazuliptitulo.setBackground(new java.awt.Color(51, 102, 255));

        IPTITULO.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        IPTITULO.setForeground(new java.awt.Color(255, 255, 255));
        IPTITULO.setText("TIENDITA INSANA");

        btnvolverflecha2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflecha2MousePressed(evt);
            }
        });

        javax.swing.GroupLayout fondoazuliptituloLayout = new javax.swing.GroupLayout(fondoazuliptitulo);
        fondoazuliptitulo.setLayout(fondoazuliptituloLayout);
        fondoazuliptituloLayout.setHorizontalGroup(
            fondoazuliptituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptituloLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnvolverflecha2)
                .addGap(151, 151, 151)
                .addComponent(IPTITULO)
                .addContainerGap(193, Short.MAX_VALUE))
        );
        fondoazuliptituloLayout.setVerticalGroup(
            fondoazuliptituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(IPTITULO, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
            .addGroup(fondoazuliptituloLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(btnvolverflecha2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(fondoazuliptitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 800, 70));

        bgsesion.setBackground(new java.awt.Color(234, 234, 234));
        bgsesion.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tztsearchlist.setBackground(new java.awt.Color(234, 234, 234));
        tztsearchlist.setBorder(javax.swing.BorderFactory.createTitledBorder("Producto / Categoría"));
        tztsearchlist.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tztsearchlistKeyReleased(evt);
            }
        });

        listaproductos.setBackground(new java.awt.Color(234, 234, 234));
        listaproductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Producto", "Categoria", "Stock", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        listaproductos.setGridColor(new java.awt.Color(234, 234, 234));
        listaproductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listaproductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(listaproductos);

        preciototal.setText("0");
        preciototal.setBorder(javax.swing.BorderFactory.createTitledBorder("Precio Total"));

        clienteproductos.setBackground(new java.awt.Color(234, 234, 234));
        clienteproductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Cantidad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(clienteproductos);

        btnvender.setText("VENDER");
        btnvender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvenderActionPerformed(evt);
            }
        });

        tztcliente1.setBackground(new java.awt.Color(234, 234, 234));
        tztcliente1.setBorder(javax.swing.BorderFactory.createTitledBorder("Cliente"));
        tztcliente1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tztcliente1KeyReleased(evt);
            }
        });

        intereslabel.setText("0");
        intereslabel.setBorder(javax.swing.BorderFactory.createTitledBorder("Interes"));

        javax.swing.GroupLayout bgsesionLayout = new javax.swing.GroupLayout(bgsesion);
        bgsesion.setLayout(bgsesionLayout);
        bgsesionLayout.setHorizontalGroup(
            bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgsesionLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgsesionLayout.createSequentialGroup()
                        .addComponent(preciototal, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(intereslabel, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(btnvender))
                    .addGroup(bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(bgsesionLayout.createSequentialGroup()
                            .addComponent(tztsearchlist, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(tztcliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        bgsesionLayout.setVerticalGroup(
            bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgsesionLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgsesionLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(bgsesionLayout.createSequentialGroup()
                        .addGroup(bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tztsearchlist, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tztcliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgsesionLayout.createSequentialGroup()
                                .addGroup(bgsesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(preciototal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(intereslabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(26, 26, 26))
                            .addGroup(bgsesionLayout.createSequentialGroup()
                                .addComponent(btnvender, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );

        jPanel2.add(bgsesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 780, 370));

        imgflechafondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha.png"))); // NOI18N
        imgflechafondo.setText("jLabel1");
        jPanel2.add(imgflechafondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, -10, 420, 510));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tztsearchlistKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tztsearchlistKeyReleased
        try {
            String buscar = tztsearchlist.getText();
            DaoVenta userproduct = new DaoVenta();
            userproduct.filtroProductos(buscar, listaproductos);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionVenta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tztsearchlistKeyReleased

    private void listaproductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listaproductosMouseClicked
        int fila = listaproductos.getSelectedRow();
        if (fila >= 0) {
            productsID.setId(parseInt((listaproductos.getValueAt(fila, 0).toString()))); //Extraer la ID de la tabla  
            try {
                dventa.buscaProducto(productsID, clienteproductos);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(GestionVenta.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Debe de seleccionar una fila");
        }
    }//GEN-LAST:event_listaproductosMouseClicked

    private void btnvenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvenderActionPerformed
        String[] opciones = { "Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Está seguro de vender?",  0, 2, null, opciones, opciones[0]);

        if(clienteproductos.getSelect().isEmpty()){
            JOptionPane.showMessageDialog(null, "Seleccione productos para vender");
        }else{
            if (selection == 1) {
                DaoProductos dproducts = new DaoProductos(); //DAO
                try {
                    String[] opciones2 = {"Aceptar"};
                    JOptionPane.showOptionDialog(null, "BOLETA ELECTRÓNICA", "Ha vendido producto/s",  0, 2, null, opciones2, opciones2[0]);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionVenta.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_btnvenderActionPerformed

    private void btnvolverflecha2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflecha2MousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionVenta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflecha2MousePressed

    private void tztcliente1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tztcliente1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tztcliente1KeyReleased

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new GestionVenta().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionVenta.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel IPTITULO;
    private javax.swing.JPanel bgsesion;
    private javax.swing.JToggleButton btnvender;
    private javax.swing.JLabel btnvolverflecha2;
    private javax.swing.JTable clienteproductos;
    private javax.swing.JPanel fondoazuliptitulo;
    private javax.swing.JLabel imgflechafondo;
    private javax.swing.JLabel intereslabel;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable listaproductos;
    private javax.swing.JLabel preciototal;
    private javax.swing.JTextField tztcliente1;
    private javax.swing.JTextField tztsearchlist;
    // End of variables declaration//GEN-END:variables
}
