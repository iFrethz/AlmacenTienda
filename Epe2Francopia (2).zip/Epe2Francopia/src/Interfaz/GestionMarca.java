package Interfaz;

import Clases.Categorias;
import Clases.Marcas;
import Conectar.DaoCategorias;
import Conectar.DaoMarcas;
import static java.lang.Integer.parseInt;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GestionMarca extends javax.swing.JFrame {

    DaoMarcas marcdao = new DaoMarcas();
    DaoCategorias catdao = new DaoCategorias();
    Marcas marcasedit = new Marcas();
    Categorias categoriaedit = new Categorias();
    
    public GestionMarca() throws ClassNotFoundException {
        initComponents();
        marcdao.cargarTabla(tablamarcas);
        catdao.cargarTabla(tablacat);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        GestionMarca = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        fondoazuliptitulo1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtaddmarca = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablamarcas = new javax.swing.JTable();
        txtnombredit = new javax.swing.JTextField();
        update = new javax.swing.JButton();
        btnvolverflecha = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        GestionCategoria = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        fondoazuliptitulo2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        txtaddcat = new javax.swing.JTextField();
        savecat = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        trashiconcat = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablacat = new javax.swing.JTable();
        txtnombrecatedit = new javax.swing.JTextField();
        updatecat = new javax.swing.JButton();
        btnvolverflecha1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        txtaddbodega = new javax.swing.JTextField();
        savebodega = new javax.swing.JButton();
        fondoazuliptitulo3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        trashiconbodega = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablabodega = new javax.swing.JTable();
        txtnumbodegaedit = new javax.swing.JTextField();
        updatebodega = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 234, 234));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fondoazuliptitulo1.setBackground(new java.awt.Color(51, 102, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("GESTIÓN DE MARCA");

        javax.swing.GroupLayout fondoazuliptitulo1Layout = new javax.swing.GroupLayout(fondoazuliptitulo1);
        fondoazuliptitulo1.setLayout(fondoazuliptitulo1Layout);
        fondoazuliptitulo1Layout.setHorizontalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        fondoazuliptitulo1Layout.setVerticalGroup(
            fondoazuliptitulo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel1.add(fondoazuliptitulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 260, 70));

        jPanel2.setBackground(new java.awt.Color(234, 234, 234));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtaddmarca.setBackground(new java.awt.Color(234, 234, 234));
        txtaddmarca.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtaddmarca.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre Marca", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtaddmarca.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        save.setBackground(new java.awt.Color(13, 112, 130));
        save.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(255, 255, 255));
        save.setText("AGREGAR");
        save.setBorderPainted(false);
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtaddmarca, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(txtaddmarca, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 290, 180));

        jPanel3.setBackground(new java.awt.Color(234, 234, 234));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        tablamarcas.setBackground(new java.awt.Color(234, 234, 234));
        tablamarcas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre Marca"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablamarcas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablamarcasMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablamarcas);

        txtnombredit.setBackground(new java.awt.Color(234, 234, 234));
        txtnombredit.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtnombredit.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre Marca", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtnombredit.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        update.setBackground(new java.awt.Color(13, 112, 130));
        update.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        update.setForeground(new java.awt.Color(255, 255, 255));
        update.setText("ACTUALIZAR");
        update.setBorderPainted(false);
        update.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(update))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(txtnombredit, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 47, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(txtnombredit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, 310, 370));

        btnvolverflecha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflechaMousePressed(evt);
            }
        });
        jPanel1.add(btnvolverflecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 465));
        jLabel1.getAccessibleContext().setAccessibleName("flechafondo");

        javax.swing.GroupLayout GestionMarcaLayout = new javax.swing.GroupLayout(GestionMarca);
        GestionMarca.setLayout(GestionMarcaLayout);
        GestionMarcaLayout.setHorizontalGroup(
            GestionMarcaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        GestionMarcaLayout.setVerticalGroup(
            GestionMarcaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Gestión Marca", GestionMarca);

        jPanel4.setBackground(new java.awt.Color(234, 234, 234));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fondoazuliptitulo2.setBackground(new java.awt.Color(51, 102, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("GESTIÓN DE CATEGORÍA");

        javax.swing.GroupLayout fondoazuliptitulo2Layout = new javax.swing.GroupLayout(fondoazuliptitulo2);
        fondoazuliptitulo2.setLayout(fondoazuliptitulo2Layout);
        fondoazuliptitulo2Layout.setHorizontalGroup(
            fondoazuliptitulo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        fondoazuliptitulo2Layout.setVerticalGroup(
            fondoazuliptitulo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel10)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel4.add(fondoazuliptitulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 300, 70));

        jPanel5.setBackground(new java.awt.Color(234, 234, 234));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtaddcat.setBackground(new java.awt.Color(234, 234, 234));
        txtaddcat.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtaddcat.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre Categoría", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtaddcat.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        savecat.setBackground(new java.awt.Color(13, 112, 130));
        savecat.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        savecat.setForeground(new java.awt.Color(255, 255, 255));
        savecat.setText("AGREGAR");
        savecat.setBorderPainted(false);
        savecat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savecatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(savecat, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtaddcat, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(txtaddcat, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(savecat, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 290, 180));

        jPanel6.setBackground(new java.awt.Color(234, 234, 234));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        trashiconcat.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        trashiconcat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        trashiconcat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        trashiconcat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                trashiconcatMouseClicked(evt);
            }
        });

        tablacat.setBackground(new java.awt.Color(234, 234, 234));
        tablacat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre Marca"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablacat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablacatMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablacat);

        txtnombrecatedit.setBackground(new java.awt.Color(234, 234, 234));
        txtnombrecatedit.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtnombrecatedit.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre Categoría", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtnombrecatedit.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        updatecat.setBackground(new java.awt.Color(13, 112, 130));
        updatecat.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        updatecat.setForeground(new java.awt.Color(255, 255, 255));
        updatecat.setText("ACTUALIZAR");
        updatecat.setBorderPainted(false);
        updatecat.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        updatecat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatecatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(trashiconcat, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(updatecat))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(txtnombrecatedit, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 47, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(txtnombrecatedit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(trashiconcat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updatecat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        jPanel4.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, 310, 370));

        btnvolverflecha1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha-izquierda.png"))); // NOI18N
        btnvolverflecha1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnvolverflecha1MousePressed(evt);
            }
        });
        jPanel4.add(btnvolverflecha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/flecha (2).png"))); // NOI18N
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 465));

        javax.swing.GroupLayout GestionCategoriaLayout = new javax.swing.GroupLayout(GestionCategoria);
        GestionCategoria.setLayout(GestionCategoriaLayout);
        GestionCategoriaLayout.setHorizontalGroup(
            GestionCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        GestionCategoriaLayout.setVerticalGroup(
            GestionCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Gestión Categoria", GestionCategoria);

        jPanel8.setBackground(new java.awt.Color(234, 234, 234));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        txtaddbodega.setBackground(new java.awt.Color(234, 234, 234));
        txtaddbodega.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtaddbodega.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Número Bodega", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtaddbodega.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        savebodega.setBackground(new java.awt.Color(13, 112, 130));
        savebodega.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        savebodega.setForeground(new java.awt.Color(255, 255, 255));
        savebodega.setText("AGREGAR");
        savebodega.setBorderPainted(false);
        savebodega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebodegaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(savebodega, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtaddbodega, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(txtaddbodega, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(savebodega, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        fondoazuliptitulo3.setBackground(new java.awt.Color(51, 102, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("GESTIÓN DE BODEGAS");

        javax.swing.GroupLayout fondoazuliptitulo3Layout = new javax.swing.GroupLayout(fondoazuliptitulo3);
        fondoazuliptitulo3.setLayout(fondoazuliptitulo3Layout);
        fondoazuliptitulo3Layout.setHorizontalGroup(
            fondoazuliptitulo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        fondoazuliptitulo3Layout.setVerticalGroup(
            fondoazuliptitulo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoazuliptitulo3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel11)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(234, 234, 234));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        trashiconbodega.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        trashiconbodega.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        trashiconbodega.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/trash32x.png"))); // NOI18N
        trashiconbodega.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                trashiconbodegaMouseClicked(evt);
            }
        });

        tablabodega.setBackground(new java.awt.Color(234, 234, 234));
        tablabodega.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Número Bodega"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablabodega.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablabodegaMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tablabodega);

        txtnumbodegaedit.setBackground(new java.awt.Color(234, 234, 234));
        txtnumbodegaedit.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtnumbodegaedit.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Número Bodega", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtnumbodegaedit.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        updatebodega.setBackground(new java.awt.Color(13, 112, 130));
        updatebodega.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        updatebodega.setForeground(new java.awt.Color(255, 255, 255));
        updatebodega.setText("ACTUALIZAR");
        updatebodega.setBorderPainted(false);
        updatebodega.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        updatebodega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebodegaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(trashiconbodega, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(updatebodega))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(txtnumbodegaedit, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 47, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(txtnumbodegaedit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(trashiconbodega, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updatebodega, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(fondoazuliptitulo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(259, 259, 259))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 149, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(fondoazuliptitulo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 19, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Gestión Bodega", jPanel7);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        Marcas marca = new Marcas();
        DaoMarcas daomarca = new DaoMarcas();

        marca.setNombre(txtaddmarca.getText());

        try {
            daomarca.crearMarca(marca);
            limpiarCamposAddMarca();
            marcdao.cargarTabla(tablamarcas);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_saveActionPerformed

    private void tablamarcasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablamarcasMouseClicked
        int fila = tablamarcas.getSelectedRow();
        if(fila >=0){
            marcasedit.setId(parseInt((tablamarcas.getValueAt(fila,0).toString()))); //Extraer la ID de la tabla
            try {
                //Buscar al usuario seleccionado según la ID
                marcdao.buscaMarca(marcasedit, txtnombredit);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
        }
    }//GEN-LAST:event_tablamarcasMouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        String[] opciones = { "Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de eliminar los datos?",  0, 2, null, opciones, opciones[0]);

        if(txtnombredit.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Seleccione marca a editar");
        }else{
            if (selection == 1) {
                DaoMarcas user = new DaoMarcas(); //DAO
                try {
                    user.eliminarMarca(marcasedit);
                    marcdao.cargarTabla(tablamarcas);
                    limpiarCamposEditMarca();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_jLabel3MouseClicked

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        DaoMarcas user = new DaoMarcas();

        marcasedit.setNombre(txtnombredit.getText());

        try {
            user.editarMarca(marcasedit);
            limpiarCamposEditMarca();
            marcdao.cargarTabla(tablamarcas);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_updateActionPerformed

    private void btnvolverflechaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflechaMousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflechaMousePressed

    private void savecatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savecatActionPerformed
        Categorias categoria = new Categorias();
        DaoCategorias daocat = new DaoCategorias();

        categoria.setNombre(txtaddcat.getText());

        try {
            daocat.crearCategoria(categoria);
            limpiarCamposAddCat();
            catdao.cargarTabla(tablacat);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_savecatActionPerformed

    private void trashiconcatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trashiconcatMouseClicked
        String[] opciones = {"Cancelar", "Aceptar"};
        var selection = JOptionPane.showOptionDialog(null, "ADVERTENCIA", "¿Estás seguro de eliminar los datos?", 0, 2, null, opciones, opciones[0]);

        if (txtnombrecatedit.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione la categoría a editar");
        } else {
            if (selection == 1) {
                DaoCategorias user = new DaoCategorias(); //DAO
                try {
                    user.eliminarCategoria(categoriaedit);
                    catdao.cargarTabla(tablacat);
                    limpiarCamposEditCat();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_trashiconcatMouseClicked

    private void tablacatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablacatMouseClicked
        int fila = tablacat.getSelectedRow();
        if (fila >= 0) {
            categoriaedit.setId(parseInt((tablacat.getValueAt(fila, 0).toString()))); //Extraer la ID de la tabla
            try {
                //Buscar al usuario seleccionado según la ID
                catdao.buscaCategoria(categoriaedit, txtnombrecatedit);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
        }
    }//GEN-LAST:event_tablacatMouseClicked

    private void updatecatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatecatActionPerformed
        DaoCategorias user = new DaoCategorias();

        categoriaedit.setNombre(txtnombrecatedit.getText());

        try {
            user.editarCategoria(categoriaedit);
            limpiarCamposEditCat();
            catdao.cargarTabla(tablacat);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_updatecatActionPerformed

    private void btnvolverflecha1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnvolverflecha1MousePressed
        try {
            MenuAdmin menuadmin = new MenuAdmin();
            dispose();
            menuadmin.setLocationRelativeTo(null);
            menuadmin.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnvolverflecha1MousePressed

    private void savebodegaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebodegaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_savebodegaActionPerformed

    private void trashiconbodegaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trashiconbodegaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_trashiconbodegaMouseClicked

    private void tablabodegaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablabodegaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tablabodegaMouseClicked

    private void updatebodegaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebodegaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updatebodegaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionMarca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionMarca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionMarca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionMarca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new GestionMarca().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(GestionMarca.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel GestionCategoria;
    private javax.swing.JPanel GestionMarca;
    private javax.swing.JLabel btnvolverflecha;
    private javax.swing.JLabel btnvolverflecha1;
    private javax.swing.JPanel fondoazuliptitulo1;
    private javax.swing.JPanel fondoazuliptitulo2;
    private javax.swing.JPanel fondoazuliptitulo3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton save;
    private javax.swing.JButton savebodega;
    private javax.swing.JButton savecat;
    private javax.swing.JTable tablabodega;
    private javax.swing.JTable tablacat;
    private javax.swing.JTable tablamarcas;
    private javax.swing.JLabel trashiconbodega;
    private javax.swing.JLabel trashiconcat;
    private javax.swing.JTextField txtaddbodega;
    private javax.swing.JTextField txtaddcat;
    private javax.swing.JTextField txtaddmarca;
    private javax.swing.JTextField txtnombrecatedit;
    private javax.swing.JTextField txtnombredit;
    private javax.swing.JTextField txtnumbodegaedit;
    private javax.swing.JButton update;
    private javax.swing.JButton updatebodega;
    private javax.swing.JButton updatecat;
    // End of variables declaration//GEN-END:variables

    private void limpiarCamposAddMarca() {
        txtaddmarca.setText("");
    }

    private void limpiarCamposEditMarca() {
        txtnombredit.setText("");
    }

    private void limpiarCamposAddCat() {
        txtaddcat.setText("");
    }

    private void limpiarCamposEditCat() {
        txtnombrecatedit.setText("");
    }

}
