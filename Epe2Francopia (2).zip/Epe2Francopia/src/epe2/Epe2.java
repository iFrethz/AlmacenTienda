package epe2;

import Interfaz.Login;

public class Epe2 {

    public static void main(String[] args) {
        Login login = new Login();
        login.setLocationRelativeTo(null);
        login.setVisible(true);
    }
    
}
