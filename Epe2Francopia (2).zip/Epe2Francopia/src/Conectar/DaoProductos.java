package Conectar;

import Clases.Productos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DaoProductos {

    private PreparedStatement stmt;
    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                               CREAR PRODUCTOS                            //
    //////////////////////////////////////////////////////////////////////////////////////////////////

    public void crearProducto(Productos producto) throws ClassNotFoundException, SQLException {
        Conecta con = new Conecta();
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = con.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM productos WHERE UPPER(nombre) = UPPER(?)");
            stmt.setString(1, producto.getNombre());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "El producto: " + producto.getNombre() + " ya existe.");
                return;
            }

            // Insertar nuevo producto
            String insertQuery = "CALL sp_agregar_producto(?,?,?,?,?,?,?,?,?);";
            PreparedStatement insertStatement = conn.prepareStatement(insertQuery);
            insertStatement.setString(1, producto.getNombre());
            insertStatement.setString(2, producto.getMarca());
            insertStatement.setString(3, producto.getCategoria());
            insertStatement.setInt(4, producto.getStock_Inicial());
            insertStatement.setInt(5, producto.getStock_Minimo());
            insertStatement.setInt(6, producto.getStock_Critico());
            insertStatement.setInt(7, producto.getStock_Maximo());
            insertStatement.setInt(8, producto.getPrecio_Venta());
            insertStatement.setInt(9, producto.getPrecio_Costo());
            insertStatement.executeUpdate(); // Ejecuta la sentencia
            JOptionPane.showMessageDialog(null, "El producto: " + producto.getNombre() + " fue creado exitosamente.");

        } catch (SQLException e) {
            System.out.println("Error al crear el producto en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                              CARGAR PRODUCTOS                           //
    //////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void cargarTabla(JTable tablaproductos) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Categoría");
        modelo.addColumn("Stock Inicial");
        modelo.addColumn("Stock Máximo");
        modelo.addColumn("Precio Venta");
        tablaproductos.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT id, nombre, categoria, stock_inicial, stock_maximo, precio_venta FROM productos";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);
                String categoria = rs.getString(3);
                int stock_inicial = rs.getInt(4);
                int stock_maximo = rs.getInt(5);
                double precio_venta = rs.getDouble(6);

                Object[] datos = {id, nombre, categoria, stock_inicial, stock_maximo, precio_venta};
                modelo.addRow(datos);
            }

            tablaproductos.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("Error al cargar la tabla de productos " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                              FILTRAR PRODUCTOS                           //
    //////////////////////////////////////////////////////////////////////////////////////////////////

    public void filtroProductos(String buscar, JTable tablaProductos) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();
        
        DefaultTableModel modelo=new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Stock Inicial");
        modelo.addColumn("Stock Mínimo");
        modelo.addColumn("Stock Crítico");
        modelo.addColumn("Stock Máximo");
        modelo.addColumn("Precio Venta");
        modelo.addColumn("Precio Costo");

        try {
            conn = con.getConnection();
            String SQL = "SELECT id, nombre, stock_inicial, stock_minimo, stock_critico, stock_maximo, precio_venta, precio_costo FROM productos WHERE nombre LIKE '" + buscar + "%'"
                    + "OR id like '" + buscar + "%'";
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(SQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);
                int stock_inicial = rs.getInt(3);
                int stock_minimo = rs.getInt(4);
                int stock_critico = rs.getInt(5);
                int stock_maximo= rs.getInt(6);
                int precio_venta = rs.getInt(7);
                int precio_costo = rs.getInt(8);

                Object[] datos = {id, nombre, stock_inicial, stock_minimo, stock_critico, stock_maximo, precio_venta, precio_costo};
                modelo.addRow(datos);
            }
            tablaProductos.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar el usuario en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                              BUSCAR PRODUCTOS                           //
    //////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void buscaProducto(Productos editProductos, JTextField txtnombre1, JTextField txtstock1, JTextField txtstockmin1, JTextField txtstockcrit1, JTextField txtstockmax1, JTextField txtprecioventa1, JTextField txtpreciocompra1) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT nombre, stock_inicial, stock_minimo, stock_critico, stock_maximo, precio_venta, precio_costo FROM productos WHERE id = " + editProductos.getId();
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                txtnombre1.setText(rs.getString(1));
                txtstock1.setText(rs.getString(2));
                txtstockmin1.setText(rs.getString(3));
                txtstockcrit1.setText(rs.getString(4));
                txtstockmax1.setText(rs.getString(5));
                txtprecioventa1.setText(rs.getString(6));
                txtpreciocompra1.setText(rs.getString(7));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar los producto en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        } 
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                              ELIMINAR PRODUCTOS                           //
    //////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void eliminarProducto(Productos producto) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "DELETE FROM productos WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, producto.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "El producto: " + producto.getNombre() + " fue eliminado.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar el producto: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                              EDITAR PRODUCTOS                           //
    //////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void editarProducto(Productos producto) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();
        
        try {
            conn = con.getConnection();
            String sql = "UPDATE productos SET nombre = ?, marca = ?, categoria = ?, stock_inicial = ?, stock_minimo = ?, stock_critico = ?, stock_maximo = ?, precio_venta = ?, precio_costo = ? WHERE id= ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getMarca());
            stmt.setString(3, producto.getCategoria());
            stmt.setInt(4, producto.getStock_Inicial());
            stmt.setInt(5, producto.getStock_Minimo());
            stmt.setInt(6, producto.getStock_Critico());
            stmt.setInt(7, producto.getStock_Maximo());
            stmt.setInt(8, producto.getPrecio_Venta());
            stmt.setInt(9, producto.getPrecio_Costo());
            stmt.setInt(10, producto.getId());
            // Ejecutar la sentencia SQL
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Producto actualizado con éxito");
        } catch (SQLException e) {
            System.out.println("Error al actualizar el producto: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }
    
}
