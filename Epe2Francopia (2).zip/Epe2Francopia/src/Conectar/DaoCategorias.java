package Conectar;

import Clases.Categorias;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DaoCategorias {

    private PreparedStatement stmt;
        public void crearCategoria(Categorias categoria) throws ClassNotFoundException, SQLException {
        Conecta con = new Conecta();
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = con.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM categoria WHERE UPPER(nombre) = UPPER(?)");
            stmt.setString(1, categoria.getNombre());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "La marca: " + categoria.getNombre() + " ya existe.");
                return;
            }

            // Insertar nuevo producto
            String insertQuery = "INSERT INTO categoria (nombre) VALUES (?)";
            PreparedStatement insertStatement = conn.prepareStatement(insertQuery);
            insertStatement.setString(1, categoria.getNombre());
            insertStatement.executeUpdate(); // Ejecuta la sentencia
            JOptionPane.showMessageDialog(null, "Categoria creada con éxito");

        } catch (SQLException e) {
            System.out.println("Error al crear la categoria en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void cargarTabla(JTable tablacat) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        tablacat.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT id, nombre FROM categoria";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);

                Object[] datos = {id, nombre};
                modelo.addRow(datos);
            }

            tablacat.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }
        
    public void eliminarCategoria(Categorias categoria) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "DELETE FROM categoria WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, categoria.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Categoria eliminada con éxito");
        } catch (SQLException e) {
            System.out.println("Error al eliminar la categoria: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }
    
        public void buscaCategoria(Categorias categoriaedit, JTextField txtnombrecatedit) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT nombre FROM categoria WHERE id = " + categoriaedit.getId();
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                txtnombrecatedit.setText(rs.getString(1));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar las tablas en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void editarCategoria(Categorias categoria) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "UPDATE categoria SET nombre = ? WHERE id= ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, categoria.getNombre());
            stmt.setInt(2, categoria.getId());
            // Ejecutar la sentencia SQL
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Categoría actualizada con éxito");
        } catch (SQLException e) {
            System.out.println("Error al actualizar la marca: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }

        public void cargarBoxCategoria(JComboBox<String> box) throws ClassNotFoundException {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT nombre FROM categoria";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String nombre = rs.getString(1);
                model.addElement(nombre);
            }
            box.setModel(model);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar las categorías en el combobox: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }
    
}
