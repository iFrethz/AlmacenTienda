package Conectar;

import Clases.Productos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DaoVenta {

    private PreparedStatement stmt;
    private String SQL;
    
        public void cargarTabla(JTable listaproductos) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Categoría");
        modelo.addColumn("Stock");
        modelo.addColumn("Precio");
        listaproductos.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String SQL = "SELECT id, nombre, categoria, stock_inicial, precio_venta FROM productos";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(SQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);
                String categoria = rs.getString(3);
                int stock_inicial = rs.getInt(4);
                double precio_venta = rs.getDouble(5);

                Object[] datos = {id, nombre, categoria, stock_inicial, precio_venta};
                modelo.addRow(datos);
            }

            listaproductos.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("Error al cargar la tabla de productos " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }

    public void filtroProductos(String buscar, JTable listaproductos) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Categoría");
        modelo.addColumn("Stock");
        modelo.addColumn("Precio");

        try {
            conn = con.getConnection();
            String SQL = "SELECT id, nombre, categoria, stock_inicial, precio_venta FROM productos WHERE nombre LIKE '" + buscar + "%'"
                    + "OR categoria like '" + buscar + "%'";
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(SQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);
                String categoria = rs.getString(3);
                int stock_inicial = rs.getInt(4);
                int precio_venta = rs.getInt(5);

                Object[] datos = {id, nombre, categoria, stock_inicial, precio_venta};
                modelo.addRow(datos);
            }
            listaproductos.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar el usuario en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }
    
public void buscaProducto(Productos ProductoID, JTable clienteproductos) throws ClassNotFoundException {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    Conecta con = new Conecta();
    
    DefaultTableModel modelo = (DefaultTableModel) clienteproductos.getModel();
    
    try {
        conn = con.getConnection();
        String SQL = "SELECT id, nombre, precio_venta FROM productos WHERE id =?";
        //Se ejecuta la orden descrita en la variable sql
        ps = conn.prepareStatement(SQL);
        ps.setInt(1, ProductoID.getId());
        rs = ps.executeQuery();
        while (rs.next()) {
            int id = rs.getInt(1);
            String nombre = rs.getString(2);
            int precio_venta = rs.getInt(3);

            Object[] datos = {id, nombre, precio_venta};
            modelo.addRow(datos);
        }
        rs.close();
        ps.close();
    } catch (SQLException e) {
        System.out.println("Error al cargar la tabla de cliente en la base de datos: " + e.getMessage());
    } finally {
        Conecta.closeConnection(conn, stmt);
    }
}
}
