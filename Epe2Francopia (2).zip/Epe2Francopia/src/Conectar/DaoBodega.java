package Conectar;

import Clases.Bodega;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DaoBodega {

    private PreparedStatement stmt;
    
        public void crearBodega(Bodega bodega) throws ClassNotFoundException, SQLException {
        Conecta con = new Conecta();
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = con.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM bodega WHERE UPPER(nombre) = UPPER(?)");
            stmt.setString(1, bodega.getNombre());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "La bodega: " + bodega.getNombre() + " ya existe.");
                return;
            }

            // Insertar nuevo producto
            String sql = "CALL sp_agregar_bodega(?);";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, bodega.getNombre());
            stmt.executeUpdate(); // Ejecuta la sentencia
            JOptionPane.showMessageDialog(null, "Bodega creada con éxito");

        } catch (SQLException e) {
            System.out.println("Error al crear la bodega en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }
    
            
        public void cargarTabla(JTable tablabodega) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        tablabodega.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT * FROM bodega";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);

                Object[] datos = {id, nombre};
                modelo.addRow(datos);
            }

            tablabodega.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }

    public void buscaBodega(Bodega bodegaedit, JTextField txtnumbodegaedit) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT nombre FROM bodega WHERE id = " + bodegaedit.getId();
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                txtnumbodegaedit.setText(rs.getString(1));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar las tablas en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

}
