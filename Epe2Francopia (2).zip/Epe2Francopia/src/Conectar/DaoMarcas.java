package Conectar;

import Clases.Marcas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DaoMarcas {

    private PreparedStatement stmt;
    
    public void crearMarca(Marcas marca) throws ClassNotFoundException, SQLException {
        Conecta con = new Conecta();
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = con.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM marca WHERE UPPER(nombre) = UPPER(?)");
            stmt.setString(1, marca.getNombre());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "La marca: " + marca.getNombre() + " ya existe.");
                return;
            }

            // Insertar nuevo producto
            String sql = "CALL sp_agregar_marca(?);";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, marca.getNombre());
            stmt.executeUpdate(); // Ejecuta la sentencia
            JOptionPane.showMessageDialog(null, "Marca creada con éxito");

        } catch (SQLException e) {
            System.out.println("Error al crear la marca en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }
    
        public void cargarTabla(JTable tablamarcas) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        tablamarcas.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT * FROM marca";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);

                Object[] datos = {id, nombre};
                modelo.addRow(datos);
            }

            tablamarcas.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }

    public void buscaMarca(Marcas marcasedit, JTextField txtnombredit) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT nombre FROM marca WHERE id = " + marcasedit.getId();
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                txtnombredit.setText(rs.getString(1));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar las tablas en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }
        
    public void eliminarMarca(Marcas marca) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "DELETE FROM marca WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, marca.getId());
            stmt.executeUpdate();
            System.out.println("Marca eliminada");
        } catch (SQLException e) {
            System.out.println("Error al eliminar la marca: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void editarMarca(Marcas marca) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "UPDATE marca SET nombre = ? WHERE id= ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, marca.getNombre());
            stmt.setInt(2, marca.getId());
            // Ejecutar la sentencia SQL
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Marca actualizada con éxito");
        } catch (SQLException e) {
            System.out.println("Error al actualizar la marca: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }
    
    public void cargarBoxMarca(JComboBox<String> box) throws ClassNotFoundException {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT nombre FROM marca";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String nombre = rs.getString(1);
                model.addElement(nombre);
            }
            box.setModel(model);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar las marcas en el combobox: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }
    
}
