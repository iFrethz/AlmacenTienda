package Conectar;

import Clases.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DaoCliente {

    private PreparedStatement stmt;

    public void crearCliente(Cliente client) throws SQLException, ClassNotFoundException {
        Conecta con = new Conecta();
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = con.getConnection(); // Obtener la conexión a la base de datos
            String sql = "CALL sp_agregar_cliente(?,?,?,?);"; //Sentencia SQL
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, client.getNombre());
            stmt.setString(2, client.getDireccion());
            stmt.setString(3, client.getTelefono());
            stmt.setFloat(4, client.getInteres());
            stmt.executeUpdate();//Ejecuta la sentencia
            JOptionPane.showMessageDialog(null, "Cliente/a creado/a con éxito");

        } catch (SQLException e) {
            System.out.println("Error, al crear un nuevo cliente desde la base de datos: " + e.getMessage());
            throw e; // Re-throw the SQLException
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void cargarTabla(JTable tablacliente) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Dirección");
        modelo.addColumn("Teléfono");
        modelo.addColumn("Interes");
        tablacliente.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "CALL sp_cargar_tabla_cliente";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String cliente = rs.getString(2);
                String direccion = rs.getString(3);
                String telefono = rs.getString(4);
                float interes = rs.getFloat(5);

                Object[] datos = {id, cliente, direccion, telefono, interes};
                modelo.addRow(datos);
            }

            tablacliente.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error, al cargar la tabla de clientes desde la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }

    public void eliminarCliente(Cliente clienteedit) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "DELETE FROM cliente WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, clienteedit.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente eliminado...");
        } catch (SQLException e) {
            System.out.println("Error, al eliminar un cliente desde la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void buscaCliente(int id, JTextField txtclientedit, JTextField txtclientdirectedit, JTextField txtclienttelefonoedit, JTextField txtclientinteresedit) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT cliente, direccion, telefono, interes FROM cliente WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                txtclientedit.setText(rs.getString(1));
                txtclientdirectedit.setText(rs.getString(2));
                txtclienttelefonoedit.setText(rs.getString(3));
                txtclientinteresedit.setText(String.valueOf(rs.getFloat(4)));
            }
        } catch (SQLException e) {
            System.out.println("Error, al buscar un cliente desde la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }

    public void filtroCliente(String buscar, JTable tablaCliente) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Direccion");
        modelo.addColumn("Teléfono");
        modelo.addColumn("Interes");

        tablaCliente.setModel(modelo);
        try {
            conn = con.getConnection();
            String SQL = "SELECT id, cliente, direccion, telefono, interes FROM cliente WHERE cliente LIKE '" + buscar + "%'"
                    + "OR interes like '" + buscar + "%'";
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(SQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String cliente = rs.getString(2);
                String direccion = rs.getString(3);
                String telefono = rs.getString(4);
                String interes = rs.getString(5);

                Object[] datos = {id, cliente, direccion, telefono, interes};
                modelo.addRow(datos);
            }
            tablaCliente.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error, al filtrar un cliente desde la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void editarCliente(Cliente cliente) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();
        try {
            // Establecer la conexión a la base de datos
            conn = con.getConnection();
            // Crear la sentencia SQL para actualizar la contraseña de un usuario por ID
            String sql = "UPDATE cliente SET cliente =?, direccion =?, telefono =?, interes =? WHERE id =?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getDireccion());
            stmt.setString(5, cliente.getTelefono());
            stmt.setFloat(6, cliente.getInteres());
            stmt.setInt(7, cliente.getId());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente actualizado con éxito");
        } catch (SQLException e) {
            System.out.println("Error, al actualizar un cliente desde la base de datos: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }
    
}
