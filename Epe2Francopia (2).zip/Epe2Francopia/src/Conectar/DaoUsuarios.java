package Conectar;

import Clases.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DaoUsuarios {

    private PreparedStatement stmt;
    //////////////////////////////////////////////////////////////////////////////////////////////////
    //                                            USUARIOS                                          //
    //////////////////////////////////////////////////////////////////////////////////////////////////
        public void crearUsuario(Usuarios usuario) throws ClassNotFoundException, SQLException  {
        Conecta con = new Conecta();
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = con.getConnection(); // Obtener la conexión a la base de datos
            String sql = "CALL sp_agregar_usuario(?,?,?,?,?,?);"; //Sentencia SQL
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, usuario.getName());
            stmt.setInt(2, usuario.getRut());
            stmt.setInt(3, usuario.getDv());
            stmt.setString(4, usuario.getRol());
            stmt.setString(5, usuario.getPassword());
            stmt.setString(6, usuario.getTelefono());
            stmt.executeUpdate();//Ejecuta la sentencia
            JOptionPane.showMessageDialog(null, "Usuario/a creado/a con éxito");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un rol para el usuario...");
            System.out.println("Error, en la base de datos: " + e.getMessage());
        } finally {
           Conecta.closeConnection(conn, stmt);
        }
    }

public Map<String, String> validateUser(String username, String password) throws ClassNotFoundException, SQLException {
    Conecta con = new Conecta();
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    Map<String, String> userData = new HashMap<>();
    boolean valid = false;

    try {
        conn = con.getConnection();
        String sql = "SELECT * FROM users WHERE usuario = ? AND pass = ?";
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, username);
        stmt.setString(2, password);
        rs = stmt.executeQuery();
        if (rs.next()) {
            String rol = rs.getString("rol"); // Asegúrate de que el nombre del campo coincida con tu base de datos
            userData.put(username, rol);
            valid = true;
        }
    } catch (SQLException e) {
        System.out.println("Error, en la base de datos: " + e.getMessage());
    } finally {
        Conecta.closeConnection(conn, stmt, rs);
    }

    // Si el usuario es válido, agrega el booleano "valid" al mapa antes de devolverlo
    userData.put("valid", String.valueOf(valid));
    return userData;
}

    public void cargarTabla(JTable tablausuarios) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Rut");
        modelo.addColumn("Nombre");
        modelo.addColumn("Role");
        modelo.addColumn("Teléfono");
        tablausuarios.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "CALL sp_cargar_tabla_usuario";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String rut = rs.getString(2);
                String usuario = rs.getString(3);
                String rol = rs.getString(4);
                String telefono = rs.getString(5);

                Object[] datos = {id, rut, usuario, rol, telefono};
                modelo.addRow(datos);
            }

            tablausuarios.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }
    
    public void filtroUsuarios(String buscar, JTable tablaUsuarios) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();
        
        DefaultTableModel modelo=new DefaultTableModel();
        modelo.addColumn("Rut");
        modelo.addColumn("Nombre");
        modelo.addColumn("Role");
        modelo.addColumn("Teléfono");

        tablaUsuarios.setModel(modelo);
        try { 
            conn = con.getConnection();
            String SQL = "SELECT CONCAT(rut, '-', dv), usuario, rol, telefono FROM users WHERE usuario LIKE '"+buscar+"%'"
            + "OR rol like '" + buscar + "%'";
           //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(SQL);
            rs = ps.executeQuery(); 
            while (rs.next()) {
                String rut = rs.getString(1);
                String usuario = rs.getString(2);
                String rol = rs.getString(3);
                String telefono = rs.getString(4);
                
                Object[] datos = {rut, usuario, rol, telefono};
                modelo.addRow(datos);
            }
            tablaUsuarios.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar el usuario en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }
    
    public void buscaUsuarios(Usuarios editUsuarios, JTextField txtnombreuseredit, JTextField txtrutedit, JTextField txtdigitadorrutedit, JComboBox boxRolUserEdit, JTextField txtcontraseñauseredit, JTextField txttelefonouseredit) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT id, usuario, rut, dv, rol, telefono, pass FROM users WHERE id = " + editUsuarios.getId();
            //Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) { 
                txtnombreuseredit.setText(rs.getString(1));
                txtrutedit.setText(rs.getString(2));
                txtdigitadorrutedit.setText(rs.getString(3));
                boxRolUserEdit.setSelectedItem(rs.getString(4));
                txttelefonouseredit.setText(rs.getString(5));
                txtcontraseñauseredit.setText(rs.getString(6));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar el usuario en la base de datos: " + e.getMessage());
        } finally {
            Conecta.closeConnection(conn, stmt);
        }
    }

    public void eliminarUsuario(Usuarios usuario) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "DELETE FROM users WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuario.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuario eliminado...");
        } catch (SQLException e) {
            System.out.println("Error al eliminar el usuario: " + e.getMessage());
        } finally {
            // Cerrar la conexión y la sentencia preparada
            Conecta.closeConnection(conn, stmt);
        }
    }

public void editarUsuario(Usuarios usuario) throws ClassNotFoundException {
    Connection conn = null;
    PreparedStatement stmt = null;
    Conecta con = new Conecta();
    try {
        // Establecer la conexión a la base de datos
        conn = con.getConnection(); 
        // Crear la sentencia SQL para actualizar la contraseña de un usuario por ID
        String sql = "UPDATE users SET usuario =?, rut =?, dv =?, rol =?, telefono =?, pass =? WHERE id =?";
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, usuario.getName());
        stmt.setInt(2, usuario.getRut());
        stmt.setInt(3, usuario.getDv());
        stmt.setString(4, usuario.getRol());
        stmt.setString(5, usuario.getTelefono());
        stmt.setString(6, usuario.getPassword());
        stmt.setInt(7, usuario.getId());
        
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(null, "Usuario actualizado con éxito");
    } catch (SQLException e) {
        System.out.println("Error al actualizar contraseña de usuario: " + e.getMessage());
    } finally {
        // Cerrar la conexión y la sentencia preparada
        Conecta.closeConnection(conn, stmt);
    }
}
    
}
