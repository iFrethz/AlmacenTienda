package Conectar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DaoHistorial {
        
    public void cargarTabla(JTable tablahistorial) throws ClassNotFoundException {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Fecha");
        modelo.addColumn("Evento");
        modelo.addColumn("Entidad");
        modelo.addColumn("Contenido");
        tablahistorial.setModel(modelo);

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Conecta con = new Conecta();

        try {
            conn = con.getConnection();
            String sql = "SELECT * FROM historial;";
            // Se ejecuta la orden descrita en la variable sql
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String fecha = rs.getString(2);
                String evento = rs.getString(3);
                String entidad = rs.getString(4);
                String contenido = rs.getString(5);

                Object[] datos = {id, fecha, evento, entidad, contenido};
                modelo.addRow(datos);
            }

            tablahistorial.setModel(modelo);
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            System.out.println("Error al cargar la tabla de historial: " + ex);
        } finally {
            Conecta.closeConnection(conn, ps);
        }
    }
}
