package Clases;

public class historial {

    private String mFecha, mEvento, mEntidad, mContenido;
    private int id;

    public String getFecha() {
        return mFecha;
    }

    public void setFecha(String mFecha) {
        this.mFecha = mFecha;
    }

    public String GetEvento() {
        return mEvento;
    }

    public void setEvento(String mEvento) {
        this.mEvento = mEvento;
    }

    public String GetEntidad() {
        return mEntidad;
    }

    public void setEntidad(String mEntidad) {
        this.mEntidad = mEntidad;
    }

    public String GetContenido() {
        return mContenido;
    }

    public void setContenido(String mContenido) {
        this.mContenido = mContenido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
