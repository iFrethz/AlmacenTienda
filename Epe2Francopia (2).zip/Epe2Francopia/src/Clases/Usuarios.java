package Clases;

public class Usuarios {

    private int id, rut, dv;
    private String name, password, rol, telefono;

    // Constructor
    public Usuarios() {
    }

    // Constructor con parámetros
    public Usuarios(int id, int rut, int dv, String name, String rol, String password, String telefono) {
        this.id = id;
        this.rut = rut;
        this.dv = dv;
        this.name = name;
        this.rol = rol;
        this.password = password;
        this.telefono = telefono;
    }

    //Getter and Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public int getDv() {
        return dv;
    }

    public void setDv(int dv) {
        this.dv = dv;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
