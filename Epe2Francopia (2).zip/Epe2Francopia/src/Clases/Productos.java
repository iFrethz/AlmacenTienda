package Clases;

public class Productos {
    private String mNombre, mMarca, mCategoria; //Sellos: Alto en azures, Alto en grasas saturadas, Alto en sodio y Alto en calorias
    private int id, mPrecio_Costo, mPrecio_Venta, mStock_Inicial, mStock_Critico, mStock_Maximo, mStock_Minimo;
    // FECHA_INGRESO Y FECHA_VENCIMIENTO
    
    // STRINGS
    public String getNombre() {
        return mNombre;
    }

    public void setNombre(String mNombre) {
        this.mNombre = mNombre;
    }

        public String getMarca() {
        return mMarca;
    }

    public void setMarca(String mMarca) {
        this.mMarca = mMarca;
    }
    
    public String getCategoria() {
        return mCategoria;
    }

    public void setCategoria(String mCategoria) {
        this.mCategoria = mCategoria;
    }

    // INTS
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    public Integer getPrecio_Costo() {
        return mPrecio_Costo;
    }
    public void setPrecio_Costo(Integer mPrecio_Costo) {
        this.mPrecio_Costo = mPrecio_Costo;
    }
    
    public Integer getPrecio_Venta() {
        return mPrecio_Venta;
    }
    public void setPrecio_Venta(Integer mPrecio_Venta) {
        this.mPrecio_Venta = mPrecio_Venta;
    }
    
    public Integer getStock_Inicial() {
        return mStock_Inicial;
    }
    public void setStock_Inicial(Integer mStock_Inicial) {
        this.mStock_Inicial = mStock_Inicial;
    }
    
    public Integer getStock_Critico() {
        return mStock_Critico;
    }
    public void setStock_Critico(Integer mStock_Critico) {
        this.mStock_Critico = mStock_Critico;
    }
    
    public Integer getStock_Maximo() {
        return mStock_Maximo;
    }
    public void setStock_Maximo(Integer mStock_Maximo) {
        this.mStock_Maximo = mStock_Maximo;
    }
        
    public Integer getStock_Minimo() {
        return mStock_Minimo;
    }
    public void setStock_Minimo(Integer mStock_Minimo) {
        this.mStock_Minimo = mStock_Minimo;
    }

}
